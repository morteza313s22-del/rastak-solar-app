import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { LogOut, Save, ShieldAlert } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "پنل مدیریت | رستاک سولار" },
      { name: "description", content: "پنل مدیریت شرکت رستاک" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

interface Settings {
  id?: string;
  cost_per_kw: number;
  tariff_per_kwh: number;
  system_efficiency: number;
  company_name: string;
  phone_primary: string;
  phone_secondary: string;
}
interface Consultation {
  id: string;
  full_name: string;
  phone: string;
  city: string | null;
  project_type: string | null;
  proposed_capacity_kw: number | null;
  description: string | null;
  status: string;
  created_at: string;
}

function AdminPage() {
  const navigate = useNavigate();
  const { user } = Route.useRouteContext();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
      const admin = (roles ?? []).some((r) => r.role === "admin");
      setIsAdmin(admin);
      const { data: s } = await supabase.from("solar_settings").select("*").limit(1).maybeSingle();
      if (s) setSettings(s as Settings);
      if (admin) {
        const { data: c } = await supabase.from("consultations").select("*").order("created_at", { ascending: false });
        setConsultations((c as Consultation[]) ?? []);
      }
    })();
  }, [user.id]);

  async function saveSettings(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    const { error } = await supabase.from("solar_settings").update({
      cost_per_kw: settings.cost_per_kw,
      tariff_per_kwh: settings.tariff_per_kwh,
      system_efficiency: settings.system_efficiency,
      company_name: settings.company_name,
      phone_primary: settings.phone_primary,
      phone_secondary: settings.phone_secondary,
      updated_at: new Date().toISOString(),
    }).eq("id", settings.id!);
    setSaving(false);
    if (error) return toast.error("ذخیره ناموفق: " + error.message);
    toast.success("تنظیمات ذخیره شد");
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  const inputCls = "w-full rounded-xl border border-white/10 bg-background/50 px-3 py-2.5 outline-none focus:border-primary";

  if (isAdmin === false) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-10">
        <div className="glass-strong rounded-2xl p-8 text-center">
          <ShieldAlert className="mx-auto mb-3 h-10 w-10 text-gold" />
          <h1 className="text-xl font-black">دسترسی مدیر ندارید</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            حساب شما ({user.email}) ثبت شده اما نقش مدیر ندارد. برای فعال‌سازی، این کد را در پشتیبانی وارد کنید یا از پایگاه داده نقش <code className="text-primary">admin</code> را برای این کاربر ثبت کنید.
          </p>
          <p className="mt-3 text-xs text-muted-foreground" dir="ltr">User ID: {user.id}</p>
          <button onClick={signOut} className="mt-6 rounded-xl bg-primary px-5 py-2.5 font-bold text-primary-foreground">خروج</button>
        </div>
      </div>
    );
  }

  if (isAdmin === null || !settings) return <div className="p-10 text-center text-muted-foreground">در حال بارگذاری...</div>;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-black text-gradient-gold">پنل مدیریت رستاک سولار</h1>
        <button onClick={signOut} className="inline-flex items-center gap-2 rounded-xl glass px-4 py-2 text-sm font-bold">
          <LogOut className="h-4 w-4" /> خروج
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={saveSettings} className="glass-strong rounded-2xl p-6">
          <h2 className="mb-4 text-lg font-black">تنظیمات ماشین حساب و شرکت</h2>
          <div className="grid gap-3">
            <label className="grid gap-1 text-sm">
              نام شرکت
              <input className={inputCls} value={settings.company_name} onChange={(e) => setSettings({ ...settings, company_name: e.target.value })} />
            </label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1 text-sm">
                تلفن اول
                <input className={inputCls} value={settings.phone_primary} onChange={(e) => setSettings({ ...settings, phone_primary: e.target.value })} dir="ltr" />
              </label>
              <label className="grid gap-1 text-sm">
                تلفن دوم
                <input className={inputCls} value={settings.phone_secondary} onChange={(e) => setSettings({ ...settings, phone_secondary: e.target.value })} dir="ltr" />
              </label>
            </div>
            <label className="grid gap-1 text-sm">
              هزینه احداث هر کیلووات (تومان)
              <input type="number" className={inputCls} value={settings.cost_per_kw} onChange={(e) => setSettings({ ...settings, cost_per_kw: Number(e.target.value) })} />
            </label>
            <label className="grid gap-1 text-sm">
              تعرفه خرید برق (تومان بر kWh)
              <input type="number" className={inputCls} value={settings.tariff_per_kwh} onChange={(e) => setSettings({ ...settings, tariff_per_kwh: Number(e.target.value) })} />
            </label>
            <label className="grid gap-1 text-sm">
              راندمان سیستم (۰ تا ۱)
              <input type="number" step="0.01" min="0" max="1" className={inputCls} value={settings.system_efficiency} onChange={(e) => setSettings({ ...settings, system_efficiency: Number(e.target.value) })} />
            </label>
            <button disabled={saving} className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 font-bold text-primary-foreground disabled:opacity-60">
              <Save className="h-4 w-4" /> {saving ? "در حال ذخیره..." : "ذخیره تنظیمات"}
            </button>
          </div>
        </form>

        <div className="glass-strong rounded-2xl p-6">
          <h2 className="mb-4 text-lg font-black">درخواست‌های مشاوره ({consultations.length})</h2>
          <div className="max-h-[600px] space-y-3 overflow-auto pr-1">
            {consultations.length === 0 && <p className="text-sm text-muted-foreground">درخواستی ثبت نشده است.</p>}
            {consultations.map((c) => (
              <div key={c.id} className="glass rounded-xl p-4 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-bold">{c.full_name}</div>
                  <a href={`tel:${c.phone}`} className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary" dir="ltr">{c.phone}</a>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {c.city && <span>{c.city} • </span>}
                  {c.project_type && <span>{c.project_type} • </span>}
                  {c.proposed_capacity_kw && <span>{c.proposed_capacity_kw} kW • </span>}
                  <span>{new Date(c.created_at).toLocaleString("fa-IR")}</span>
                </div>
                {c.description && <p className="mt-2 text-sm">{c.description}</p>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
