import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Sun } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "ورود مدیر | رستاک سولار" },
      { name: "description", content: "ورود به پنل مدیریت رستاک سولار" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin" });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    if (mode === "signin") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) return toast.error("ورود ناموفق: " + error.message);
      toast.success("خوش آمدید");
      navigate({ to: "/admin" });
    } else {
      const { error } = await supabase.auth.signUp({
        email, password,
        options: { emailRedirectTo: window.location.origin + "/admin" },
      });
      setLoading(false);
      if (error) return toast.error("ثبت‌نام ناموفق: " + error.message);
      toast.success("ثبت‌نام انجام شد. برای دسترسی مدیر با پشتیبانی تماس بگیرید.");
    }
  }

  const inputCls = "w-full rounded-xl border border-white/10 bg-background/50 px-4 py-3 outline-none focus:border-primary";

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form onSubmit={submit} className="glass-strong w-full max-w-md rounded-3xl p-8">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/20 text-primary">
            <Sun className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-lg font-black">پنل مدیریت رستاک سولار</h1>
            <p className="text-xs text-muted-foreground">{mode === "signin" ? "ورود" : "ثبت‌نام مدیر"}</p>
          </div>
        </div>
        <div className="grid gap-3">
          <input type="email" required placeholder="ایمیل" value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} dir="ltr" />
          <input type="password" required minLength={6} placeholder="رمز عبور" value={password} onChange={(e) => setPassword(e.target.value)} className={inputCls} dir="ltr" />
          <button disabled={loading} className="rounded-xl bg-primary px-4 py-3 font-bold text-primary-foreground disabled:opacity-60">
            {loading ? "در حال پردازش..." : mode === "signin" ? "ورود" : "ثبت‌نام"}
          </button>
          <button type="button" onClick={() => setMode(mode === "signin" ? "signup" : "signin")} className="text-sm text-muted-foreground hover:text-foreground">
            {mode === "signin" ? "ثبت‌نام مدیر جدید" : "قبلاً ثبت‌نام کرده‌ام"}
          </button>
          <a href="/" className="text-center text-xs text-muted-foreground hover:underline">بازگشت به سایت</a>
        </div>
      </form>
    </div>
  );
}
