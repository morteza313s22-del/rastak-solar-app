import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Phone, MessageCircle, Calculator, ArrowLeft, Sun, Wrench, ShieldCheck, HeadphonesIcon, Leaf, Factory, Home } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";
import { SolarCalculator } from "@/components/solar-calculator";
import { ConsultationForm } from "@/components/consultation-form";
import { EngineeringDesign } from "@/components/engineering-design";

import heroVilla from "@/assets/hero-villa.jpg";
import industrialImg from "@/assets/project-industrial.jpg";
import agriImg from "@/assets/project-agri.jpg";
import installImg from "@/assets/project-install.jpg";

export const Route = createFileRoute("/")({
  component: LandingPage,
});

const DEFAULTS = {
  cost_per_kw: 55_000_000,
  tariff_per_kwh: 16_000,
  system_efficiency: 0.78,
  company_name: "شرکت عمران و انرژی رستاک",
  phone_primary: "09123532459",
  phone_secondary: "09368510090",
};

const SAMPLE_PROJECTS = [
  { title: "نیروگاه ویلایی مسکونی", location: "قم — پردیسان", capacity_kw: 12, project_type: "خانگی", image_url: heroVilla },
  { title: "نیروگاه صنعتی سوله", location: "اصفهان — شهرک صنعتی", capacity_kw: 250, project_type: "صنعتی", image_url: industrialImg },
  { title: "نیروگاه کشاورزی", location: "یزد — اردکان", capacity_kw: 80, project_type: "کشاورزی", image_url: agriImg },
  { title: "نصب توسط تیم اجرایی", location: "تهران", capacity_kw: 20, project_type: "خانگی", image_url: installImg },
];

const SERVICES = [
  { icon: Home, title: "نیروگاه خورشیدی خانگی", desc: "طراحی و اجرای نیروگاه‌های ۵ تا ۲۵ کیلوواتی روی بام منازل و ویلاها." },
  { icon: Leaf, title: "نیروگاه خورشیدی کشاورزی", desc: "تأمین برق چاه‌ها و کشاورزی، همراه با فروش تضمینی مازاد به شبکه." },
  { icon: Factory, title: "نیروگاه خورشیدی صنعتی", desc: "نیروگاه‌های مقیاس بزرگ روی سوله و اراضی کارخانه‌ها." },
  { icon: Sun, title: "مشاوره و طراحی", desc: "امکان‌سنجی رایگان، طراحی سیستم بهینه و برآورد دقیق درآمد." },
  { icon: Wrench, title: "نصب و اجرا", desc: "اجرای حرفه‌ای توسط تیم متخصص با تجهیزات درجه یک." },
  { icon: HeadphonesIcon, title: "پشتیبانی و نگهداری", desc: "خدمات پس از فروش، مانیتورینگ و نگهداری بلندمدت نیروگاه." },
];

function LandingPage() {
  const { data: settings } = useQuery({
    queryKey: ["solar-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("solar_settings").select("*").limit(1).maybeSingle();
      return data ?? DEFAULTS;
    },
  });

  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data } = await supabase.from("projects").select("*").order("display_order", { ascending: true });
      return data && data.length > 0 ? data : null;
    },
  });

  const s = settings ?? DEFAULTS;
  const displayProjects = projects ?? SAMPLE_PROJECTS;

  return (
    <div className="min-h-screen">
      <SiteHeader />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img src={heroVilla} alt="" className="h-full w-full object-cover" width={1600} height={1000} />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-white/60 to-white/90" />
          <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-b from-transparent to-background" />
        </div>
        <div className="mx-auto max-w-7xl px-4 pb-16 pt-14 sm:px-6 sm:pt-20 lg:pb-24 lg:pt-28">
          <div className="max-w-3xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs">
              <Sun className="h-4 w-4 text-gold" />
              انرژی پاک، درآمد پایدار
            </div>
            <h1 className="text-4xl font-black leading-tight sm:text-5xl lg:text-6xl">
              <span className="text-gradient-gold">{s.company_name}</span>
            </h1>
            <p className="mt-4 text-lg text-muted-foreground sm:text-xl">
              طراحی، اجرا و احداث نیروگاه‌های خورشیدی <span className="text-primary">خانگی</span>،{" "}
              <span className="text-primary">کشاورزی</span> و <span className="text-primary">صنعتی</span>
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#contact" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 font-bold text-primary-foreground shadow-xl shadow-primary/25">
                مشاوره رایگان
                <ArrowLeft className="h-4 w-4" />
              </a>
              <a href="#calculator" className="inline-flex items-center gap-2 rounded-full glass-strong px-6 py-3.5 font-bold">
                <Calculator className="h-4 w-4 text-gold" />
                محاسبه درآمد نیروگاه
              </a>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-3 text-sm">
              <a href={`tel:${s.phone_primary}`} className="inline-flex items-center gap-2 rounded-full glass px-4 py-2 font-semibold">
                <Phone className="h-4 w-4 text-primary" />{s.phone_primary}
              </a>
              <a href={`tel:${s.phone_secondary}`} className="inline-flex items-center gap-2 rounded-full glass px-4 py-2 font-semibold">
                <Phone className="h-4 w-4 text-primary" />{s.phone_secondary}
              </a>
              <a
                href={`https://wa.me/98${s.phone_primary.replace(/^0/, "")}`}
                target="_blank"
                rel="noopener"
                className="inline-flex items-center gap-2 rounded-full bg-[oklch(0.7_0.17_150)] px-4 py-2 font-bold text-primary-foreground"
              >
                <MessageCircle className="h-4 w-4" />
                واتساپ
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <SectionTitle eyebrow="خدمات" title="راهکار جامع انرژی خورشیدی" />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => (
            <div key={s.title} className="glass rounded-2xl p-6 transition hover:-translate-y-1 hover:ring-1 hover:ring-primary/40">
              <div className="mb-3 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary/25 to-gold/15 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Projects */}
      <section id="projects" className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <SectionTitle eyebrow="نمونه کارها" title="پروژه‌های اجرا شده" />
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {displayProjects.map((p, i) => (
            <article key={i} className="glass group overflow-hidden rounded-2xl">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={p.image_url ?? heroVilla}
                  alt={p.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-4">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="inline-block rounded-full bg-primary/15 px-2 py-0.5 text-[11px] font-bold text-primary">
                    {p.project_type}
                  </span>
                  {p.capacity_kw ? (
                    <span className="text-gold text-xs font-bold">{p.capacity_kw} kW</span>
                  ) : null}
                </div>
                <h3 className="font-bold">{p.title}</h3>
              </div>

            </article>
          ))}
        </div>
      </section>

      {/* Calculator */}
      <section id="calculator" className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <SectionTitle eyebrow="ماشین حساب" title="درآمد نیروگاه خورشیدی خود را برآورد کنید" />
        <div className="mt-8">
          <SolarCalculator settings={{
            cost_per_kw: Number(s.cost_per_kw),
            tariff_per_kwh: Number(s.tariff_per_kwh),
            system_efficiency: Number(s.system_efficiency),
          }} />
        </div>
      </section>

      {/* Engineering design */}
      <section id="engineering" className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <SectionTitle eyebrow="مهندسی" title="طراحی و مهندسی نیروگاه خورشیدی" />
        <p className="mx-auto mt-3 max-w-2xl text-center text-sm text-muted-foreground">
          طراحی String، انتخاب اینورتر، محاسبه کابل و استراکچر به همراه گزارش حرفه‌ای پروژه.
        </p>
        <div className="mt-8">
          <EngineeringDesign tariff={Number(s.tariff_per_kwh)} />
        </div>
      </section>

      {/* Trust badges */}
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="glass grid gap-3 rounded-2xl p-4 text-sm sm:grid-cols-3">
          <TrustItem icon={<ShieldCheck className="h-5 w-5 text-primary" />} text="ضمانت کیفیت اجرا" />
          <TrustItem icon={<Sun className="h-5 w-5 text-gold" />} text="تجهیزات درجه یک" />
          <TrustItem icon={<HeadphonesIcon className="h-5 w-5 text-primary" />} text="پشتیبانی بلندمدت" />
        </div>
      </section>

      {/* Contact form */}
      <section id="contact" className="mx-auto max-w-4xl px-4 py-14 sm:px-6">
        <SectionTitle eyebrow="تماس با ما" title="درخواست مشاوره رایگان" />
        <p className="mx-auto mt-3 max-w-2xl text-center text-sm text-muted-foreground">
          فرم زیر را پر کنید، کارشناسان ما در اسرع وقت با شما تماس می‌گیرند.
        </p>
        <div className="mt-8">
          <ConsultationForm />
        </div>
      </section>

      <SiteFooter phone1={s.phone_primary} phone2={s.phone_secondary} />
    </div>
  );
}

function SectionTitle({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="text-center">
      <div className="mb-2 text-xs font-bold uppercase tracking-widest text-gradient-gold">{eyebrow}</div>
      <h2 className="text-2xl font-black sm:text-3xl lg:text-4xl">{title}</h2>
    </div>
  );
}

function TrustItem({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl px-3 py-2">
      {icon}
      <span className="font-semibold">{text}</span>
    </div>
  );
}
