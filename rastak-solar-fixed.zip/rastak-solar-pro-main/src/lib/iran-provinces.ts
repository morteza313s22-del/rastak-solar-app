// Iranian provinces with representative cities and solar irradiation data.
// radiation = kWh/m²/day annual average; sun_hours = peak sun hours/day.
export interface CityData {
  name: string;
  radiation: number;
  sun_hours: number;
}
export interface Province {
  name: string;
  cities: CityData[];
}

export const PROVINCES: Province[] = [
  { name: "قم", cities: [
    { name: "قم", radiation: 5.5, sun_hours: 5.8 },
    { name: "پردیسان", radiation: 5.5, sun_hours: 5.8 },
    { name: "جعفریه", radiation: 5.6, sun_hours: 5.9 },
    { name: "کهک", radiation: 5.5, sun_hours: 5.8 },
  ]},
  { name: "تهران", cities: [
    { name: "تهران", radiation: 5.1, sun_hours: 5.3 },
    { name: "ورامین", radiation: 5.3, sun_hours: 5.5 },
    { name: "پاکدشت", radiation: 5.2, sun_hours: 5.4 },
    { name: "شهریار", radiation: 5.1, sun_hours: 5.3 },
    { name: "دماوند", radiation: 5.0, sun_hours: 5.2 },
  ]},
  { name: "اصفهان", cities: [
    { name: "اصفهان", radiation: 5.6, sun_hours: 5.9 },
    { name: "کاشان", radiation: 5.7, sun_hours: 6.0 },
    { name: "نجف‌آباد", radiation: 5.6, sun_hours: 5.9 },
    { name: "خمینی‌شهر", radiation: 5.6, sun_hours: 5.9 },
    { name: "شاهین‌شهر", radiation: 5.6, sun_hours: 5.9 },
  ]},
  { name: "یزد", cities: [
    { name: "یزد", radiation: 5.9, sun_hours: 6.2 },
    { name: "میبد", radiation: 5.9, sun_hours: 6.2 },
    { name: "اردکان", radiation: 6.0, sun_hours: 6.3 },
    { name: "بافق", radiation: 6.1, sun_hours: 6.4 },
  ]},
  { name: "کرمان", cities: [
    { name: "کرمان", radiation: 5.8, sun_hours: 6.1 },
    { name: "سیرجان", radiation: 5.9, sun_hours: 6.2 },
    { name: "رفسنجان", radiation: 5.9, sun_hours: 6.2 },
    { name: "بم", radiation: 6.0, sun_hours: 6.3 },
    { name: "جیرفت", radiation: 5.8, sun_hours: 6.1 },
  ]},
  { name: "فارس", cities: [
    { name: "شیراز", radiation: 5.5, sun_hours: 5.8 },
    { name: "مرودشت", radiation: 5.6, sun_hours: 5.9 },
    { name: "جهرم", radiation: 5.7, sun_hours: 6.0 },
    { name: "لار", radiation: 5.6, sun_hours: 5.9 },
    { name: "کازرون", radiation: 5.5, sun_hours: 5.8 },
  ]},
  { name: "خراسان رضوی", cities: [
    { name: "مشهد", radiation: 5.0, sun_hours: 5.2 },
    { name: "نیشابور", radiation: 5.1, sun_hours: 5.3 },
    { name: "سبزوار", radiation: 5.2, sun_hours: 5.4 },
    { name: "تربت حیدریه", radiation: 5.2, sun_hours: 5.4 },
    { name: "کاشمر", radiation: 5.2, sun_hours: 5.4 },
  ]},
  { name: "خراسان جنوبی", cities: [
    { name: "بیرجند", radiation: 5.7, sun_hours: 6.0 },
    { name: "قائن", radiation: 5.6, sun_hours: 5.9 },
    { name: "طبس", radiation: 5.9, sun_hours: 6.2 },
  ]},
  { name: "خراسان شمالی", cities: [
    { name: "بجنورد", radiation: 5.0, sun_hours: 5.2 },
    { name: "اسفراین", radiation: 5.0, sun_hours: 5.2 },
    { name: "شیروان", radiation: 4.9, sun_hours: 5.1 },
  ]},
  { name: "آذربایجان شرقی", cities: [
    { name: "تبریز", radiation: 4.8, sun_hours: 5.0 },
    { name: "مراغه", radiation: 4.9, sun_hours: 5.1 },
    { name: "میانه", radiation: 4.9, sun_hours: 5.1 },
    { name: "اهر", radiation: 4.8, sun_hours: 5.0 },
  ]},
  { name: "آذربایجان غربی", cities: [
    { name: "ارومیه", radiation: 4.9, sun_hours: 5.1 },
    { name: "خوی", radiation: 4.9, sun_hours: 5.1 },
    { name: "مهاباد", radiation: 4.8, sun_hours: 5.0 },
    { name: "بوکان", radiation: 4.8, sun_hours: 5.0 },
  ]},
  { name: "خوزستان", cities: [
    { name: "اهواز", radiation: 5.3, sun_hours: 5.5 },
    { name: "دزفول", radiation: 5.3, sun_hours: 5.5 },
    { name: "آبادان", radiation: 5.4, sun_hours: 5.6 },
    { name: "بهبهان", radiation: 5.3, sun_hours: 5.5 },
    { name: "ماهشهر", radiation: 5.4, sun_hours: 5.6 },
  ]},
  { name: "سیستان و بلوچستان", cities: [
    { name: "زاهدان", radiation: 5.9, sun_hours: 6.2 },
    { name: "زابل", radiation: 6.0, sun_hours: 6.3 },
    { name: "چابهار", radiation: 5.6, sun_hours: 5.8 },
    { name: "ایرانشهر", radiation: 6.0, sun_hours: 6.3 },
  ]},
  { name: "هرمزگان", cities: [
    { name: "بندرعباس", radiation: 5.5, sun_hours: 5.7 },
    { name: "قشم", radiation: 5.5, sun_hours: 5.7 },
    { name: "کیش", radiation: 5.6, sun_hours: 5.8 },
    { name: "میناب", radiation: 5.5, sun_hours: 5.7 },
  ]},
  { name: "بوشهر", cities: [
    { name: "بوشهر", radiation: 5.4, sun_hours: 5.6 },
    { name: "برازجان", radiation: 5.5, sun_hours: 5.7 },
    { name: "گناوه", radiation: 5.4, sun_hours: 5.6 },
    { name: "عسلویه", radiation: 5.5, sun_hours: 5.7 },
  ]},
  { name: "مرکزی", cities: [
    { name: "اراک", radiation: 5.3, sun_hours: 5.5 },
    { name: "ساوه", radiation: 5.4, sun_hours: 5.6 },
    { name: "خمین", radiation: 5.3, sun_hours: 5.5 },
    { name: "محلات", radiation: 5.3, sun_hours: 5.5 },
  ]},
  { name: "همدان", cities: [
    { name: "همدان", radiation: 5.0, sun_hours: 5.2 },
    { name: "ملایر", radiation: 5.1, sun_hours: 5.3 },
    { name: "نهاوند", radiation: 5.1, sun_hours: 5.3 },
  ]},
  { name: "قزوین", cities: [
    { name: "قزوین", radiation: 5.1, sun_hours: 5.3 },
    { name: "تاکستان", radiation: 5.1, sun_hours: 5.3 },
    { name: "آبیک", radiation: 5.0, sun_hours: 5.2 },
  ]},
  { name: "کرمانشاه", cities: [
    { name: "کرمانشاه", radiation: 5.2, sun_hours: 5.4 },
    { name: "اسلام‌آبادغرب", radiation: 5.2, sun_hours: 5.4 },
    { name: "کنگاور", radiation: 5.2, sun_hours: 5.4 },
    { name: "سنقر", radiation: 5.1, sun_hours: 5.3 },
  ]},
  { name: "گیلان", cities: [
    { name: "رشت", radiation: 4.2, sun_hours: 4.3 },
    { name: "بندرانزلی", radiation: 4.1, sun_hours: 4.2 },
    { name: "لاهیجان", radiation: 4.2, sun_hours: 4.3 },
    { name: "آستارا", radiation: 4.1, sun_hours: 4.2 },
  ]},
  { name: "مازندران", cities: [
    { name: "ساری", radiation: 4.3, sun_hours: 4.4 },
    { name: "بابل", radiation: 4.3, sun_hours: 4.4 },
    { name: "آمل", radiation: 4.3, sun_hours: 4.4 },
    { name: "قائم‌شهر", radiation: 4.3, sun_hours: 4.4 },
    { name: "چالوس", radiation: 4.2, sun_hours: 4.3 },
  ]},
  { name: "گلستان", cities: [
    { name: "گرگان", radiation: 4.5, sun_hours: 4.6 },
    { name: "گنبد کاووس", radiation: 4.6, sun_hours: 4.7 },
    { name: "آق‌قلا", radiation: 4.5, sun_hours: 4.6 },
  ]},
  { name: "زنجان", cities: [
    { name: "زنجان", radiation: 5.0, sun_hours: 5.2 },
    { name: "ابهر", radiation: 5.0, sun_hours: 5.2 },
    { name: "خدابنده", radiation: 5.0, sun_hours: 5.2 },
  ]},
  { name: "سمنان", cities: [
    { name: "سمنان", radiation: 5.3, sun_hours: 5.5 },
    { name: "شاهرود", radiation: 5.3, sun_hours: 5.5 },
    { name: "دامغان", radiation: 5.4, sun_hours: 5.6 },
    { name: "گرمسار", radiation: 5.3, sun_hours: 5.5 },
  ]},
  { name: "لرستان", cities: [
    { name: "خرم‌آباد", radiation: 5.2, sun_hours: 5.4 },
    { name: "بروجرد", radiation: 5.2, sun_hours: 5.4 },
    { name: "دورود", radiation: 5.1, sun_hours: 5.3 },
    { name: "الیگودرز", radiation: 5.2, sun_hours: 5.4 },
  ]},
  { name: "کردستان", cities: [
    { name: "سنندج", radiation: 5.2, sun_hours: 5.4 },
    { name: "سقز", radiation: 5.1, sun_hours: 5.3 },
    { name: "مریوان", radiation: 5.1, sun_hours: 5.3 },
    { name: "بانه", radiation: 5.0, sun_hours: 5.2 },
  ]},
  { name: "اردبیل", cities: [
    { name: "اردبیل", radiation: 4.8, sun_hours: 5.0 },
    { name: "مشگین‌شهر", radiation: 4.8, sun_hours: 5.0 },
    { name: "پارس‌آباد", radiation: 4.9, sun_hours: 5.1 },
  ]},
  { name: "چهارمحال و بختیاری", cities: [
    { name: "شهرکرد", radiation: 5.5, sun_hours: 5.8 },
    { name: "بروجن", radiation: 5.5, sun_hours: 5.8 },
    { name: "فارسان", radiation: 5.4, sun_hours: 5.6 },
  ]},
  { name: "کهگیلویه و بویراحمد", cities: [
    { name: "یاسوج", radiation: 5.4, sun_hours: 5.6 },
    { name: "گچساران", radiation: 5.4, sun_hours: 5.6 },
    { name: "دهدشت", radiation: 5.3, sun_hours: 5.5 },
  ]},
  { name: "ایلام", cities: [
    { name: "ایلام", radiation: 5.3, sun_hours: 5.5 },
    { name: "دهلران", radiation: 5.4, sun_hours: 5.6 },
    { name: "مهران", radiation: 5.3, sun_hours: 5.5 },
  ]},
  { name: "البرز", cities: [
    { name: "کرج", radiation: 5.1, sun_hours: 5.3 },
    { name: "فردیس", radiation: 5.1, sun_hours: 5.3 },
    { name: "نظرآباد", radiation: 5.2, sun_hours: 5.4 },
    { name: "اشتهارد", radiation: 5.2, sun_hours: 5.4 },
  ]},
];
