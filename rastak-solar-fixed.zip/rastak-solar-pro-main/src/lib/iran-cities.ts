export interface IranCity {
  province: string;
  city: string;
  radiation: number; // kWh/m²/day annual average
  sun_hours: number; // peak sun hours per day (useful daily sunlight)
}

// sun_hours ≈ peak sun hours (kWh/m²/day). Values approximated per region.
export const IRAN_CITIES: IranCity[] = [
  { province: "قم", city: "قم", radiation: 5.5, sun_hours: 5.8 },
  { province: "تهران", city: "تهران", radiation: 5.1, sun_hours: 5.3 },
  { province: "اصفهان", city: "اصفهان", radiation: 5.6, sun_hours: 5.9 },
  { province: "یزد", city: "یزد", radiation: 5.9, sun_hours: 6.2 },
  { province: "کرمان", city: "کرمان", radiation: 5.8, sun_hours: 6.1 },
  { province: "فارس", city: "شیراز", radiation: 5.5, sun_hours: 5.8 },
  { province: "خراسان رضوی", city: "مشهد", radiation: 5.0, sun_hours: 5.2 },
  { province: "آذربایجان شرقی", city: "تبریز", radiation: 4.8, sun_hours: 5.0 },
  { province: "خوزستان", city: "اهواز", radiation: 5.3, sun_hours: 5.5 },
  { province: "سیستان و بلوچستان", city: "زاهدان", radiation: 5.9, sun_hours: 6.2 },
  { province: "هرمزگان", city: "بندرعباس", radiation: 5.5, sun_hours: 5.7 },
  { province: "بوشهر", city: "بوشهر", radiation: 5.4, sun_hours: 5.6 },
  { province: "مرکزی", city: "اراک", radiation: 5.3, sun_hours: 5.5 },
  { province: "همدان", city: "همدان", radiation: 5.0, sun_hours: 5.2 },
  { province: "قزوین", city: "قزوین", radiation: 5.1, sun_hours: 5.3 },
  { province: "کرمانشاه", city: "کرمانشاه", radiation: 5.2, sun_hours: 5.4 },
  { province: "گیلان", city: "رشت", radiation: 4.2, sun_hours: 4.3 },
  { province: "مازندران", city: "ساری", radiation: 4.3, sun_hours: 4.4 },
  { province: "گلستان", city: "گرگان", radiation: 4.5, sun_hours: 4.6 },
  { province: "زنجان", city: "زنجان", radiation: 5.0, sun_hours: 5.2 },
  { province: "سمنان", city: "سمنان", radiation: 5.3, sun_hours: 5.5 },
  { province: "لرستان", city: "خرم‌آباد", radiation: 5.2, sun_hours: 5.4 },
  { province: "کردستان", city: "سنندج", radiation: 5.2, sun_hours: 5.4 },
  { province: "اردبیل", city: "اردبیل", radiation: 4.8, sun_hours: 5.0 },
  { province: "چهارمحال و بختیاری", city: "شهرکرد", radiation: 5.5, sun_hours: 5.8 },
  { province: "کهگیلویه و بویراحمد", city: "یاسوج", radiation: 5.4, sun_hours: 5.6 },
  { province: "ایلام", city: "ایلام", radiation: 5.3, sun_hours: 5.5 },
  { province: "خراسان جنوبی", city: "بیرجند", radiation: 5.7, sun_hours: 6.0 },
  { province: "خراسان شمالی", city: "بجنورد", radiation: 5.0, sun_hours: 5.2 },
  { province: "آذربایجان غربی", city: "ارومیه", radiation: 4.9, sun_hours: 5.1 },
  { province: "البرز", city: "کرج", radiation: 5.1, sun_hours: 5.3 },
];
