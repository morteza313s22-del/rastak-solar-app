import { useMemo, useState, useRef } from "react";
import { PROVINCES } from "@/lib/iran-provinces";
import {
  Sun, Zap, Wallet, TrendingUp, Clock, MapPin, Gauge, Leaf, TreePine,
  Download, FileSpreadsheet, Printer, Share2, Save, GitCompare, Settings2,
  Factory, Home, Sprout, Building2, Grid3x3, PowerOff, DollarSign, Battery,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  BarChart, Bar, AreaChart, Area,
} from "recharts";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import logoAsset from "@/assets/rastak-logo.png.asset.json";


interface Settings {
  cost_per_kw: number;
  tariff_per_kwh: number;
  system_efficiency: number;
}

const formatIRR = (n: number) => new Intl.NumberFormat("fa-IR").format(Math.round(n));
const formatNum = (n: number, d = 0) => new Intl.NumberFormat("fa-IR", { maximumFractionDigits: d }).format(n);
const formatToman = (n: number) => {
  if (n >= 1_000_000_000) return `${formatNum(n / 1_000_000_000, 2)} میلیارد`;
  if (n >= 1_000_000) return `${formatNum(n / 1_000_000, 1)} میلیون`;
  return formatIRR(n);
};

const PLANT_TYPES = [
  { value: "residential", label: "خانگی", icon: Home },
  { value: "agricultural", label: "کشاورزی", icon: Sprout },
  { value: "industrial", label: "صنعتی", icon: Factory },
  { value: "commercial", label: "تجاری", icon: Building2 },
  { value: "utility", label: "مقیاس بزرگ", icon: Grid3x3 },
  { value: "offgrid", label: "منفصل از شبکه", icon: PowerOff },
];

const MONTH_FACTORS = [1.05, 1.08, 1.10, 1.08, 1.05, 1.00, 0.95, 0.95, 0.98, 1.00, 0.92, 0.84];
const MONTH_NAMES = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

export const PANEL_PRESETS = [450, 550, 580, 600, 650];

interface CalcInputs {
  capacity: number;
  provinceIdx: number;
  cityIdx: number;
  gps: string;
  sunHoursDaily: number;
  sunHoursAnnual: number;
  efficiency: number;
  losses: number;
  degradation: number;
  costPerKw: number;
  tariff: number;
  maintenance: number;
  inflation: number;
  priceGrowth: number;
  lifetime: number;
  plantType: string;
  panelMode: "preset" | "manual";
  panelWatt: number;
  panelLength: number;
  panelWidth: number;
  landFactor: number;
}

export function computePanel(i: CalcInputs) {
  const watt = Math.max(1, i.panelWatt || 1);
  const count = Math.ceil((i.capacity * 1000) / watt);
  const totalKw = (count * watt) / 1000;
  const panelArea = Math.max(0, i.panelLength) * Math.max(0, i.panelWidth);
  const modulesArea = panelArea * count;
  const landArea = modulesArea * Math.max(1, i.landFactor || 1);
  return { watt, count, totalKw, panelArea, modulesArea, landArea };
}


function makeDefaultInputs(settings: Settings): CalcInputs {
  const p = PROVINCES[0];
  const c = p.cities[0];
  return {
    capacity: 20,
    provinceIdx: 0,
    cityIdx: 0,
    gps: "",
    sunHoursDaily: c.sun_hours,
    sunHoursAnnual: Math.round(c.sun_hours * 365),
    efficiency: Math.round((settings.system_efficiency || 0.8) * 100),
    losses: 14,
    degradation: 0.6,
    costPerKw: settings.cost_per_kw,
    tariff: settings.tariff_per_kwh,
    maintenance: 5_000_000,
    inflation: 40,
    priceGrowth: 25,
    lifetime: 25,
    plantType: "residential",
    panelMode: "preset",
    panelWatt: 580,
    panelLength: 2.28,
    panelWidth: 1.13,
    landFactor: 2,
  };

}

function computeResults(i: CalcInputs) {
  const pr = (i.efficiency / 100) * (1 - i.losses / 100);
  const dailyKWh = i.capacity * i.sunHoursDaily * pr;
  const annualKWh_y1 = i.capacity * i.sunHoursAnnual * pr;
  const monthlyKWh = annualKWh_y1 / 12;
  const monthly = MONTH_FACTORS.map((f, idx) => ({
    month: MONTH_NAMES[idx],
    تولید: Math.round(monthlyKWh * f),
    درآمد: Math.round(monthlyKWh * f * i.tariff / 1_000_000),
  }));

  const dailyIncome = dailyKWh * i.tariff;
  const annualIncome_y1 = annualKWh_y1 * i.tariff;
  const monthlyIncome_y1 = annualIncome_y1 / 12;

  const initialInvestment = i.capacity * i.costPerKw;
  const netAnnualY1 = annualIncome_y1 - i.maintenance;

  const years: {
    year: number;
    kwh: number;
    revenue: number;
    maintenance: number;
    net: number;
    cumulative: number;
    roi: number;
  }[] = [];
  let cumulative = -initialInvestment;
  for (let y = 1; y <= i.lifetime; y++) {
    const kwh = annualKWh_y1 * Math.pow(1 - i.degradation / 100, y - 1);
    const priceFactor = Math.pow(1 + i.priceGrowth / 100, y - 1);
    const maintFactor = Math.pow(1 + i.inflation / 100, y - 1);
    const revenue = kwh * i.tariff * priceFactor;
    const maint = i.maintenance * maintFactor;
    const net = revenue - maint;
    cumulative += net;
    years.push({
      year: y,
      kwh: Math.round(kwh),
      revenue: Math.round(revenue),
      maintenance: Math.round(maint),
      net: Math.round(net),
      cumulative: Math.round(cumulative),
      roi: (cumulative / initialInvestment) * 100,
    });
  }

  // Payback period (fractional year)
  let payback = 0;
  let running = -initialInvestment;
  for (let y = 1; y <= i.lifetime; y++) {
    const prev = running;
    running += years[y - 1].net;
    if (running >= 0 && prev < 0) {
      payback = y - 1 + (-prev) / years[y - 1].net;
      break;
    }
  }
  if (payback === 0 && running < 0) payback = i.lifetime;

  const cumAt = (y: number) => years[Math.min(y, i.lifetime) - 1]?.cumulative ?? 0;
  const co2 = annualKWh_y1 * 0.73; // kg CO2/kWh
  const trees = co2 / 21; // ~21 kg CO2 per tree/year

  return {
    pr, dailyKWh, annualKWh: annualKWh_y1, monthlyKWh, dailyIncome,
    monthlyIncome: monthlyIncome_y1, annualIncome: annualIncome_y1,
    initialInvestment, netAnnual: netAnnualY1,
    profit5: cumAt(5), profit10: cumAt(10), profit20: cumAt(20), profit25: cumAt(Math.min(25, i.lifetime)),
    roi: (cumAt(i.lifetime) / initialInvestment) * 100,
    payback, co2: co2 * i.lifetime, treesEq: Math.round(trees * i.lifetime),
    monthly, years,
  };
}

type Results = ReturnType<typeof computeResults>;

export function SolarCalculator({ settings }: { settings: Settings }) {
  const [inputs, setInputs] = useState<CalcInputs>(() => makeDefaultInputs(settings));
  const [tab, setTab] = useState<"inputs" | "results" | "charts" | "compare">("inputs");
  const [compareB, setCompareB] = useState<CalcInputs | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const province = PROVINCES[inputs.provinceIdx];
  const city = province.cities[inputs.cityIdx];
  const results = useMemo(() => computeResults(inputs), [inputs]);
  const resultsB = useMemo(() => (compareB ? computeResults(compareB) : null), [compareB]);

  const update = <K extends keyof CalcInputs>(k: K, v: CalcInputs[K]) =>
    setInputs((s) => ({ ...s, [k]: v }));

  const setProvince = (idx: number) => {
    const c = PROVINCES[idx].cities[0];
    setInputs((s) => ({
      ...s, provinceIdx: idx, cityIdx: 0,
      sunHoursDaily: c.sun_hours, sunHoursAnnual: Math.round(c.sun_hours * 365),
    }));
  };
  const setCity = (idx: number) => {
    const c = PROVINCES[inputs.provinceIdx].cities[idx];
    setInputs((s) => ({
      ...s, cityIdx: idx, sunHoursDaily: c.sun_hours,
      sunHoursAnnual: Math.round(c.sun_hours * 365),
    }));
  };

  const saveLocal = () => {
    try {
      const key = `rastak-calc-${Date.now()}`;
      const list = JSON.parse(localStorage.getItem("rastak-calcs") || "[]");
      list.push({ id: key, at: new Date().toISOString(), inputs, summary: {
        capacity: inputs.capacity, city: `${province.name} — ${city.name}`,
        payback: results.payback, roi: results.roi,
      }});
      localStorage.setItem("rastak-calcs", JSON.stringify(list.slice(-20)));
      toast.success("محاسبات ذخیره شد");
    } catch { toast.error("ذخیره ناموفق"); }
  };

  const exportExcel = () => {
    const wb = XLSX.utils.book_new();
    const summary = [
      ["گزارش نیروگاه خورشیدی — رستاک سولار"],
      ["تاریخ گزارش", new Date().toLocaleDateString("fa-IR")],
      [],
      ["ظرفیت (kW)", inputs.capacity],
      ["استان", province.name],
      ["شهر", city.name],
      ["نوع نیروگاه", PLANT_TYPES.find(p => p.value === inputs.plantType)?.label ?? ""],
      ["ساعات آفتاب روزانه", inputs.sunHoursDaily],
      ["راندمان (%)", inputs.efficiency],
      ["افت سیستم (%)", inputs.losses],
      ["افت سالانه پنل (%)", inputs.degradation],
      [],
      ["تولید سالانه (kWh)", Math.round(results.annualKWh)],
      ["سرمایه اولیه (تومان)", Math.round(results.initialInvestment)],
      ["درآمد سالانه (تومان)", Math.round(results.annualIncome)],
      ["سود خالص سال اول (تومان)", Math.round(results.netAnnual)],
      ["بازگشت سرمایه (سال)", results.payback.toFixed(2)],
      ["ROI کل (%)", results.roi.toFixed(1)],
      ["کاهش CO₂ کل عمر (kg)", Math.round(results.co2)],
      ["معادل درخت", results.treesEq],
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summary), "خلاصه");
    const yearsSheet: (string | number)[][] = [["سال", "تولید (kWh)", "درآمد", "نگهداری", "سود خالص", "سود تجمعی", "ROI %"]];
    results.years.forEach((y) => yearsSheet.push([y.year, y.kwh, y.revenue, y.maintenance, y.net, y.cumulative, +y.roi.toFixed(1)]));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(yearsSheet), "جریان نقدی");
    const monthlySheet: (string | number)[][] = [["ماه", "تولید (kWh)", "درآمد (میلیون تومان)"]];
    results.monthly.forEach((m) => monthlySheet.push([m.month, m.تولید, m.درآمد]));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(monthlySheet), "ماهانه");
    XLSX.writeFile(wb, `rastak-solar-${inputs.capacity}kW.xlsx`);
    toast.success("فایل اکسل دانلود شد");
  };

  const buildReportHTML = () => {
    const persianDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
      dateStyle: "full",
    }).format(new Date());
    const fa = (n: number, d = 0) =>
      new Intl.NumberFormat("fa-IR", { maximumFractionDigits: d }).format(n);
    const plantLabel =
      PLANT_TYPES.find((p) => p.value === inputs.plantType)?.label ?? "";

    const projectRows: [string, string][] = [
      ["ظرفیت نیروگاه", `${fa(inputs.capacity)} کیلووات`],
      ["استان / شهر", `${province.name} — ${city.name}`],
      ["نوع نیروگاه", plantLabel],
      ["میانگین تابش روزانه", `${fa(inputs.sunHoursDaily, 2)} ساعت`],
      ["راندمان سیستم", `${fa(inputs.efficiency)} ٪`],
      ["تلفات سیستم", `${fa(inputs.losses, 1)} ٪`],
      ["افت سالانه پنل", `${fa(inputs.degradation, 2)} ٪`],
      ["هزینه احداث هر کیلووات", `${fa(inputs.costPerKw)} تومان`],
      ["قیمت خرید برق", `${fa(inputs.tariff)} تومان / kWh`],
    ];

    const resultRows: [string, string][] = [
      ["تولید سالانه برق", `${fa(results.annualKWh)} کیلووات‌ساعت`],
      ["تولید ماهانه برق", `${fa(results.monthlyKWh)} کیلووات‌ساعت`],
      ["سرمایه اولیه", `${fa(results.initialInvestment)} تومان`],
      ["درآمد سال اول", `${fa(results.annualIncome)} تومان`],
      ["سود خالص سال اول", `${fa(results.netAnnual)} تومان`],
      ["سود تجمعی ۵ ساله", `${fa(results.profit5)} تومان`],
      ["سود تجمعی ۱۰ ساله", `${fa(results.profit10)} تومان`],
      ["سود تجمعی ۲۰ ساله", `${fa(results.profit20)} تومان`],
      [`سود تجمعی ${fa(Math.min(25, inputs.lifetime))} ساله`, `${fa(results.profit25)} تومان`],
      ["مدت بازگشت سرمایه", `${fa(results.payback, 1)} سال`],
      ["نرخ بازگشت سرمایه (ROI)", `${fa(results.roi, 1)} ٪`],
      ["کاهش انتشار CO₂", `${fa(results.co2)} کیلوگرم`],
      ["معادل تعداد درختان", `${fa(results.treesEq)} درخت`],
    ];

    const tableRows = (rows: [string, string][]) =>
      rows
        .map(([k, v]) => `<tr><td class="k">${k}</td><td class="v">${v}</td></tr>`)
        .join("");

    return `<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8" />
<title>گزارش تحلیل سرمایه‌گذاری نیروگاه خورشیدی</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
  *,*::before,*::after{box-sizing:border-box}
  html,body{margin:0;padding:0;font-family:'Vazirmatn',Tahoma,sans-serif;color:#0f1e3d;background:#fff}
  .page{width:794px;margin:0 auto;padding:36px 40px;background:#fff}
  .brand{display:flex;align-items:center;justify-content:space-between;gap:16px;padding-bottom:16px;border-bottom:3px solid #16a34a}
  .brand-l{display:flex;align-items:center;gap:14px}
  .brand img{width:64px;height:64px;object-fit:contain}
  .brand h1{margin:0;font-size:20px;font-weight:900;color:#0f1e3d}
  .brand .sub{font-size:12px;color:#4b5563;margin-top:2px}
  .date-chip{background:linear-gradient(135deg,#16a34a,#0f9d58);color:#fff;padding:8px 14px;border-radius:999px;font-size:12px;font-weight:700}
  .title-wrap{margin:22px 0 18px;text-align:center}
  .title-wrap h2{margin:0;font-size:24px;font-weight:900;color:#0f1e3d}
  .title-wrap .accent{display:inline-block;width:80px;height:4px;background:linear-gradient(90deg,#eab308,#16a34a);border-radius:4px;margin-top:10px}
  .section{margin-top:22px}
  .section-head{display:flex;align-items:center;gap:10px;margin-bottom:10px}
  .section-head .badge{width:32px;height:32px;border-radius:10px;background:linear-gradient(135deg,#16a34a,#0f9d58);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:14px}
  .section-head h3{margin:0;font-size:16px;font-weight:800;color:#0f1e3d}
  table{width:100%;border-collapse:separate;border-spacing:0;border:1.5px solid #d1d5db;border-radius:12px;overflow:hidden;font-size:13px}
  td{padding:10px 14px;border-bottom:1px solid #e5e7eb;text-align:right}
  tr:last-child td{border-bottom:none}
  td.k{background:#f9fafb;color:#374151;font-weight:600;width:45%}
  td.v{color:#065f46;font-weight:800;background:#f0fdf4}
  .kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0 4px}
  .kpi{border:1.5px solid #d1fae5;border-radius:12px;padding:10px 12px;background:linear-gradient(135deg,#f0fdf4,#fefce8)}
  .kpi .lbl{font-size:10px;color:#4b5563}
  .kpi .val{font-size:14px;font-weight:900;color:#065f46;margin-top:2px}
  .footer{margin-top:28px;padding-top:14px;border-top:2px solid #eab308;text-align:center;font-size:11px;color:#374151;line-height:1.9}
  .footer strong{color:#0f1e3d;font-size:12px}
  .footer .row{display:flex;justify-content:center;gap:14px;flex-wrap:wrap;margin-top:4px}
  @media print{@page{size:A4;margin:0}body{margin:0}}
</style></head>
<body><div class="page" id="report-root">
  <div class="brand">
    <div class="brand-l">
      <img src="${logoAsset.url}" alt="لوگو" crossorigin="anonymous" />
      <div>
        <h1>شرکت عمران و انرژی رستاک</h1>
        <div class="sub">طراحی، مشاوره و اجرای نیروگاه‌های خورشیدی</div>
      </div>
    </div>
    <div class="date-chip">${persianDate}</div>
  </div>
  <div class="title-wrap">
    <h2>گزارش تحلیل سرمایه‌گذاری نیروگاه خورشیدی</h2>
    <div class="accent"></div>
  </div>
  <div class="kpi-row">
    <div class="kpi"><div class="lbl">ظرفیت</div><div class="val">${fa(inputs.capacity)} kW</div></div>
    <div class="kpi"><div class="lbl">سرمایه اولیه</div><div class="val">${fa(results.initialInvestment)} ت</div></div>
    <div class="kpi"><div class="lbl">درآمد سالانه</div><div class="val">${fa(results.annualIncome)} ت</div></div>
    <div class="kpi"><div class="lbl">بازگشت سرمایه</div><div class="val">${fa(results.payback, 1)} سال</div></div>
  </div>
  <div class="section">
    <div class="section-head"><span class="badge">۱</span><h3>اطلاعات پروژه</h3></div>
    <table><tbody>${tableRows(projectRows)}</tbody></table>
  </div>
  <div class="section">
    <div class="section-head"><span class="badge">۲</span><h3>نتایج محاسبات</h3></div>
    <table><tbody>${tableRows(resultRows)}</tbody></table>
  </div>
  <div class="footer">
    <strong>شرکت عمران و انرژی رستاک</strong><br/>
    طراحی، مشاوره و اجرای نیروگاه‌های خورشیدی
    <div class="row"><span>۰۹۱۲۳۵۳۲۴۵۹</span><span>۰۹۳۶۸۵۱۰۰۹۰</span><span>قم</span></div>
  </div>
</div></body></html>`;
  };

  // Render the report inside an isolated iframe so page-level Tailwind v4
  // stylesheets (which use oklch() and other modern color functions that
  // html2canvas cannot parse) never leak into the capture. This was the
  // root cause of "Error creating report".
  const renderReportIframe = async (): Promise<{
    iframe: HTMLIFrameElement;
    body: HTMLElement;
  }> => {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("aria-hidden", "true");
    iframe.style.cssText =
      "position:fixed;top:0;left:-10000px;width:820px;height:1200px;border:0;background:#fff;";
    document.body.appendChild(iframe);
    const doc = iframe.contentDocument!;
    doc.open();
    doc.write(buildReportHTML());
    doc.close();
    const win = iframe.contentWindow as Window & {
      document: Document & { fonts?: { ready: Promise<unknown> } };
    };
    try { await win.document.fonts?.ready; } catch { /* noop */ }
    const img = doc.querySelector("img");
    if (img && !img.complete) {
      await new Promise<void>((r) => {
        img.onload = () => r();
        img.onerror = () => r();
      });
    }
    await new Promise((r) => setTimeout(r, 80));
    const body = doc.querySelector<HTMLElement>("#report-root") ?? doc.body;
    iframe.style.height = `${body.scrollHeight + 20}px`;
    return { iframe, body };
  };

  const exportPDF = async () => {
    toast.loading("در حال آماده‌سازی گزارش...", { id: "pdf" });
    let iframe: HTMLIFrameElement | null = null;
    try {
      const rendered = await renderReportIframe();
      iframe = rendered.iframe;
      const canvas = await html2canvas(rendered.body, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
        windowWidth: rendered.body.scrollWidth,
        windowHeight: rendered.body.scrollHeight,
      });
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgW = pageW;
      const imgH = (canvas.height * imgW) / canvas.width;
      const imgData = canvas.toDataURL("image/jpeg", 0.95);
      let heightLeft = imgH;
      let position = 0;
      pdf.addImage(imgData, "JPEG", 0, position, imgW, imgH);
      heightLeft -= pageH;
      while (heightLeft > 0) {
        position = heightLeft - imgH;
        pdf.addPage();
        pdf.addImage(imgData, "JPEG", 0, position, imgW, imgH);
        heightLeft -= pageH;
      }
      pdf.save(`گزارش-رستاک-سولار-${inputs.capacity}kW.pdf`);
      toast.success("گزارش PDF دانلود شد", { id: "pdf" });
    } catch (e) {
      console.error("[pdf-export]", e);
      const msg = e instanceof Error ? e.message : String(e);
      toast.error(`خطا در ساخت گزارش: ${msg}`, { id: "pdf" });
    } finally {
      if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);
    }
  };

  const printReport = () => {
    const html = buildReportHTML();
    const w = window.open("", "_blank", "width=900,height=1000");
    if (!w) { toast.error("پنجره چاپ باز نشد"); return; }
    w.document.open();
    w.document.write(
      html + `<script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),500)});<\/script>`
    );
    w.document.close();
  };
  const shareReport = async () => {
    const text = `گزارش نیروگاه ${inputs.capacity} کیلوواتی در ${province.name} — ${city.name}\n` +
      `تولید سالانه: ${formatIRR(results.annualKWh)} kWh\n` +
      `درآمد سالانه: ${formatToman(results.annualIncome)} تومان\n` +
      `بازگشت سرمایه: ${formatNum(results.payback, 1)} سال\n` +
      `ROI کل: ${formatNum(results.roi, 1)}٪`;
    try {
      if (navigator.share) await navigator.share({ title: "رستاک سولار", text });
      else { await navigator.clipboard.writeText(text); toast.success("خلاصه کپی شد"); }
    } catch { /* cancelled */ }
  };

  const toggleCompare = () => {
    if (compareB) { setCompareB(null); setTab("inputs"); return; }
    setCompareB({ ...inputs, capacity: inputs.capacity * 2 });
    setTab("compare");
  };

  return (
    <div ref={printRef} className="glass-strong rounded-3xl p-4 sm:p-8 print:bg-white print:shadow-none">
      {/* Header */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-primary to-primary/60 text-white shadow-lg">
            <Sun className="h-7 w-7" />
          </div>
          <div className="min-w-0">
            <h3 className="truncate text-lg font-black sm:text-2xl">داشبورد سرمایه‌گذاری نیروگاه خورشیدی</h3>
            <p className="text-xs text-muted-foreground">تحلیل کامل بازدهی سرمایه — رستاک سولار</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 print:hidden">
          <ActionBtn onClick={saveLocal} icon={<Save className="h-4 w-4" />} label="ذخیره" />
          <ActionBtn onClick={exportPDF} icon={<Download className="h-4 w-4" />} label="دانلود PDF" />
          <ActionBtn onClick={exportExcel} icon={<FileSpreadsheet className="h-4 w-4" />} label="Excel" />
          <ActionBtn onClick={printReport} icon={<Printer className="h-4 w-4" />} label="چاپ PDF" />

          <ActionBtn onClick={shareReport} icon={<Share2 className="h-4 w-4" />} label="اشتراک" />
          <ActionBtn onClick={toggleCompare} icon={<GitCompare className="h-4 w-4" />} label={compareB ? "لغو مقایسه" : "مقایسه"} highlight={!!compareB} />
        </div>
      </div>

      {/* KPI Strip */}
      <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-4 sm:gap-3">
        <KpiCard icon={<Zap />} label="تولید سالانه" value={`${formatIRR(results.annualKWh)}`} unit="kWh" gradient="from-primary/20 to-primary/5" />
        <KpiCard icon={<Wallet />} label="سرمایه اولیه" value={formatToman(results.initialInvestment)} unit="تومان" gradient="from-gold/20 to-gold/5" />
        <KpiCard icon={<TrendingUp />} label="درآمد سالانه" value={formatToman(results.annualIncome)} unit="تومان" gradient="from-primary/20 to-gold/10" />
        <KpiCard icon={<Clock />} label="بازگشت سرمایه" value={formatNum(results.payback, 1)} unit="سال" gradient="from-navy/20 to-primary/10" />
      </div>

      {/* Tabs */}
      <div className="mb-6 flex flex-wrap gap-2 print:hidden">
        <TabBtn active={tab === "inputs"} onClick={() => setTab("inputs")} icon={<Settings2 className="h-4 w-4" />}>ورودی‌ها</TabBtn>
        <TabBtn active={tab === "results"} onClick={() => setTab("results")} icon={<Gauge className="h-4 w-4" />}>نتایج</TabBtn>
        <TabBtn active={tab === "charts"} onClick={() => setTab("charts")} icon={<TrendingUp className="h-4 w-4" />}>نمودارها</TabBtn>
        {compareB && <TabBtn active={tab === "compare"} onClick={() => setTab("compare")} icon={<GitCompare className="h-4 w-4" />}>مقایسه</TabBtn>}
      </div>

      {(tab === "inputs" || (typeof window !== "undefined" && window.matchMedia?.("print").matches)) && (
        <InputsPanel
          inputs={inputs} update={update}
          province={province} city={city}
          setProvince={setProvince} setCity={setCity}
        />
      )}
      {tab === "results" && <ResultsPanel inputs={inputs} results={results} />}
      {tab === "charts" && <ChartsPanel results={results} />}
      {tab === "compare" && compareB && resultsB && (
        <ComparePanel
          a={{ inputs, results }} b={{ inputs: compareB, results: resultsB }}
          setB={setCompareB}
        />
      )}

      <p className="mt-6 text-xs text-muted-foreground print:hidden">
        * محاسبات جنبه تخمینی دارد. تولید سالانه = ظرفیت × ساعات آفتاب سالانه × راندمان × (۱ − افت سیستم). افت سالانه پنل، تورم و رشد قیمت برق در تحلیل ۲۵ ساله لحاظ شده است.
      </p>
    </div>
  );
}

/* -------------------- Sub-components -------------------- */

function ActionBtn({ onClick, icon, label, highlight }: { onClick: () => void; icon: React.ReactNode; label: string; highlight?: boolean }) {
  return (
    <button onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition hover:scale-[1.02] ${
        highlight ? "border-primary bg-primary/10 text-primary" : "border-white/20 bg-white/50 text-foreground hover:border-primary/40"
      }`}>
      {icon}{label}
    </button>
  );
}

function TabBtn({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition ${
        active ? "bg-gradient-to-l from-primary to-primary/80 text-white shadow-md"
               : "bg-white/40 text-foreground hover:bg-white/70"
      }`}>
      {icon}{children}
    </button>
  );
}

function KpiCard({ icon, label, value, unit, gradient }: { icon: React.ReactNode; label: string; value: string; unit: string; gradient: string }) {
  return (
    <div className={`glass rounded-2xl bg-gradient-to-br ${gradient} p-3 sm:p-4 ring-1 ring-white/40 transition hover:scale-[1.02]`}>
      <div className="mb-1 flex items-center gap-1.5 text-[10px] text-muted-foreground sm:text-xs">
        <span className="text-primary [&>svg]:h-3.5 [&>svg]:w-3.5 sm:[&>svg]:h-4 sm:[&>svg]:w-4">{icon}</span>
        {label}
      </div>
      <div className="text-sm font-black leading-tight sm:text-xl">{value}</div>
      <div className="text-[10px] text-muted-foreground sm:text-xs">{unit}</div>
    </div>
  );
}

function InputsPanel({
  inputs, update, province, city, setProvince, setCity,
}: {
  inputs: CalcInputs;
  update: <K extends keyof CalcInputs>(k: K, v: CalcInputs[K]) => void;
  province: (typeof PROVINCES)[number]; city: (typeof PROVINCES)[number]["cities"][number];
  setProvince: (i: number) => void; setCity: (i: number) => void;
}) {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Plant Type Selector */}
      <div>
        <div className="mb-2 text-sm font-bold">نوع نیروگاه</div>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
          {PLANT_TYPES.map((p) => {
            const Ic = p.icon;
            const active = inputs.plantType === p.value;
            return (
              <button key={p.value} onClick={() => update("plantType", p.value)}
                className={`flex flex-col items-center gap-1.5 rounded-2xl border p-3 text-xs font-bold transition ${
                  active ? "border-primary bg-primary/10 text-primary shadow-md"
                         : "border-white/30 bg-white/40 hover:border-primary/40"
                }`}>
                <Ic className="h-5 w-5" />
                {p.label}
              </button>
            );
          })}
        </div>
      </div>

      <SectionCard title="ظرفیت و موقعیت" icon={<MapPin className="h-4 w-4" />}>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <NumberField label="ظرفیت نیروگاه (kW)" value={inputs.capacity} min={1} max={10000}
            onChange={(v) => update("capacity", v)} slider />
          <SelectField label="استان" value={inputs.provinceIdx} onChange={(v) => setProvince(v)}
            options={PROVINCES.map((p, i) => ({ v: i, label: p.name }))} />
          <SelectField label="شهر" value={inputs.cityIdx} onChange={(v) => setCity(v)}
            options={province.cities.map((c, i) => ({ v: i, label: c.name }))} />
          <TextField label="مختصات GPS (اختیاری)" placeholder="34.6416, 50.8746"
            value={inputs.gps} onChange={(v) => update("gps", v)} />
          <NumberField label="ساعات آفتاب مفید روزانه" value={inputs.sunHoursDaily} min={1} max={12} step={0.1}
            onChange={(v) => update("sunHoursDaily", v)} />
          <NumberField label="ساعات آفتاب سالانه" value={inputs.sunHoursAnnual} min={365} max={4380}
            onChange={(v) => update("sunHoursAnnual", v)} />
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <MiniInfo label="تابش روزانه" value={`${formatNum(city.radiation, 2)} kWh/m²`} />
          <MiniInfo label="تابش سالانه" value={`${formatIRR(city.radiation * 365)} kWh/m²`} />
          <MiniInfo label="منطقه" value={`${province.name} — ${city.name}`} />
        </div>
      </SectionCard>

      <PanelSection inputs={inputs} update={update} />



      <SectionCard title="عملکرد و افت سیستم" icon={<Gauge className="h-4 w-4" />}>
        <div className="grid gap-4 md:grid-cols-3">
          <NumberField label="راندمان سیستم (٪)" value={inputs.efficiency} min={50} max={95}
            onChange={(v) => update("efficiency", v)} slider />
          <NumberField label="افت سیستم (٪)" value={inputs.losses} min={0} max={40} step={0.5}
            onChange={(v) => update("losses", v)} slider />
          <NumberField label="افت سالانه پنل (٪)" value={inputs.degradation} min={0} max={2} step={0.1}
            onChange={(v) => update("degradation", v)} />
        </div>
      </SectionCard>

      <SectionCard title="اقتصاد پروژه" icon={<DollarSign className="h-4 w-4" />}>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <NumberField label="هزینه احداث هر kW (تومان)" value={inputs.costPerKw} min={0} step={1_000_000}
            onChange={(v) => update("costPerKw", v)} />
          <NumberField label="قیمت خرید برق (تومان/kWh)" value={inputs.tariff} min={0} step={500}
            onChange={(v) => update("tariff", v)} />
          <NumberField label="هزینه سالانه نگهداری (تومان)" value={inputs.maintenance} min={0} step={500_000}
            onChange={(v) => update("maintenance", v)} />
          <NumberField label="نرخ تورم (٪)" value={inputs.inflation} min={0} max={100} step={1}
            onChange={(v) => update("inflation", v)} />
          <NumberField label="رشد سالانه قیمت برق (٪)" value={inputs.priceGrowth} min={0} max={100} step={1}
            onChange={(v) => update("priceGrowth", v)} />
          <NumberField label="عمر نیروگاه (سال)" value={inputs.lifetime} min={5} max={40}
            onChange={(v) => update("lifetime", v)} slider />
        </div>
      </SectionCard>
    </div>
  );
}

function PanelSection({ inputs, update }: {
  inputs: CalcInputs;
  update: <K extends keyof CalcInputs>(k: K, v: CalcInputs[K]) => void;
}) {
  const p = computePanel(inputs);
  const r = computeResults(inputs);
  return (
    <SectionCard title="انتخاب پنل خورشیدی" icon={<Battery className="h-4 w-4" />}>
      <div className="mb-4 flex flex-wrap gap-2">
        <button onClick={() => update("panelMode", "preset")}
          className={`rounded-xl border px-3 py-2 text-xs font-bold transition ${
            inputs.panelMode === "preset" ? "border-primary bg-primary/10 text-primary" : "border-white/30 bg-white/40"
          }`}>انتخاب از لیست پنل‌های آماده</button>
        <button onClick={() => update("panelMode", "manual")}
          className={`rounded-xl border px-3 py-2 text-xs font-bold transition ${
            inputs.panelMode === "manual" ? "border-primary bg-primary/10 text-primary" : "border-white/30 bg-white/40"
          }`}>تنظیم دستی توان پنل</button>
      </div>

      {inputs.panelMode === "preset" ? (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
          {PANEL_PRESETS.map((w) => (
            <button key={w} onClick={() => update("panelWatt", w)}
              className={`rounded-xl border px-2 py-3 text-sm font-black transition ${
                inputs.panelWatt === w ? "border-primary bg-primary/10 text-primary shadow-md" : "border-white/30 bg-white/40 hover:border-primary/40"
              }`} dir="ltr">{w}W</button>
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          <NumberField label="توان هر پنل (وات)" value={inputs.panelWatt} min={50} max={1000} step={5}
            onChange={(v) => update("panelWatt", v)} />
          <div className="md:col-span-2 flex flex-wrap items-end gap-2">
            {[410, 450, 550, 580, 610, 700].map((w) => (
              <button key={w} onClick={() => update("panelWatt", w)} dir="ltr"
                className="rounded-lg border border-white/30 bg-white/50 px-2.5 py-1.5 text-xs font-bold hover:border-primary/50">{w}W</button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        <NumberField label="طول پنل (متر)" value={inputs.panelLength} min={0.5} max={4} step={0.01}
          onChange={(v) => update("panelLength", v)} />
        <NumberField label="عرض پنل (متر)" value={inputs.panelWidth} min={0.3} max={3} step={0.01}
          onChange={(v) => update("panelWidth", v)} />
        <NumberField label="ضریب سطح زمین (فاصله بین ردیف‌ها)" value={inputs.landFactor} min={1} max={4} step={0.1}
          onChange={(v) => update("landFactor", v)} />
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-3 lg:grid-cols-4">
        <MiniInfo label="توان هر پنل" value={`${formatNum(p.watt)} وات`} />
        <MiniInfo label="تعداد پنل" value={`${formatNum(p.count)} عدد`} />
        <MiniInfo label="ظرفیت کل پنل‌ها" value={`${formatNum(p.totalKw, 2)} kW`} />
        <MiniInfo label="مساحت هر پنل" value={`${formatNum(p.panelArea, 2)} m²`} />
        <MiniInfo label="مساحت کل پنل‌ها" value={`${formatNum(p.modulesArea, 1)} m²`} />
        <MiniInfo label="سطح تقریبی زمین موردنیاز" value={`${formatNum(p.landArea, 1)} m²`} />
        <MiniInfo label="تولید سالانه" value={`${formatIRR(r.annualKWh)} kWh`} />
        <MiniInfo label="درآمد تقریبی سالانه" value={`${formatToman(r.annualIncome)} تومان`} />
      </div>
    </SectionCard>
  );
}



function SectionCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl p-4 sm:p-5">
      <div className="mb-4 flex items-center gap-2 text-sm font-black">
        <span className="grid h-7 w-7 place-items-center rounded-lg bg-primary/15 text-primary">{icon}</span>
        {title}
      </div>
      {children}
    </div>
  );
}

function MiniInfo({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-gradient-to-br from-primary/10 to-gold/10 p-2.5 ring-1 ring-primary/20">
      <div className="text-[10px] text-muted-foreground">{label}</div>
      <div className="text-sm font-bold">{value}</div>
    </div>
  );
}

function NumberField({ label, value, onChange, min, max, step = 1, slider }: {
  label: string; value: number; onChange: (v: number) => void;
  min?: number; max?: number; step?: number; slider?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs text-muted-foreground">{label}</span>
      <input type="number" value={value} min={min} max={max} step={step}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="w-full rounded-xl border border-white/30 bg-white/60 px-3 py-2.5 text-base font-bold outline-none focus:border-primary" />
      {slider && min !== undefined && max !== undefined && (
        <input type="range" value={value} min={min} max={max} step={step}
          onChange={(e) => onChange(Number(e.target.value))}
          className="mt-2 w-full accent-primary" />
      )}
    </label>
  );
}

function TextField({ label, value, onChange, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs text-muted-foreground">{label}</span>
      <input type="text" value={value} placeholder={placeholder} dir="ltr"
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-white/30 bg-white/60 px-3 py-2.5 text-sm outline-none focus:border-primary" />
    </label>
  );
}

function SelectField({ label, value, onChange, options }: {
  label: string; value: number; onChange: (v: number) => void;
  options: { v: number; label: string }[];
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs text-muted-foreground">{label}</span>
      <select value={value} onChange={(e) => onChange(Number(e.target.value))}
        className="w-full rounded-xl border border-white/30 bg-white/60 px-3 py-2.5 outline-none focus:border-primary">
        {options.map((o) => <option key={o.v} value={o.v}>{o.label}</option>)}
      </select>
    </label>
  );
}

function ResultsPanel({ inputs, results }: { inputs: CalcInputs; results: Results }) {
  const cards: { icon: React.ReactNode; label: string; value: string; sub?: string; tint: "green" | "gold" | "navy" }[] = [
    { icon: <Zap />, label: "تولید روزانه", value: `${formatIRR(results.dailyKWh)} kWh`, tint: "green" },
    { icon: <Zap />, label: "تولید ماهانه", value: `${formatIRR(results.monthlyKWh)} kWh`, tint: "green" },
    { icon: <Zap />, label: "تولید سالانه", value: `${formatIRR(results.annualKWh)} kWh`, tint: "green" },
    { icon: <Wallet />, label: "سرمایه اولیه", value: `${formatToman(results.initialInvestment)} تومان`, tint: "navy" },
    { icon: <DollarSign />, label: "درآمد روزانه", value: `${formatIRR(results.dailyIncome)} تومان`, tint: "gold" },
    { icon: <DollarSign />, label: "درآمد ماهانه", value: `${formatToman(results.monthlyIncome)} تومان`, tint: "gold" },
    { icon: <TrendingUp />, label: "درآمد سالانه", value: `${formatToman(results.annualIncome)} تومان`, tint: "gold" },
    { icon: <Battery />, label: "سود خالص سالانه", value: `${formatToman(results.netAnnual)} تومان`, sub: "پس از نگهداری", tint: "green" },
    { icon: <TrendingUp />, label: "سود ۵ ساله", value: formatToman(results.profit5), sub: "تومان", tint: "green" },
    { icon: <TrendingUp />, label: "سود ۱۰ ساله", value: formatToman(results.profit10), sub: "تومان", tint: "green" },
    { icon: <TrendingUp />, label: "سود ۲۰ ساله", value: formatToman(results.profit20), sub: "تومان", tint: "gold" },
    { icon: <TrendingUp />, label: `سود ${formatNum(Math.min(25, inputs.lifetime))} ساله`, value: formatToman(results.profit25), sub: "تومان", tint: "gold" },
    { icon: <Gauge />, label: "بازده کل (ROI)", value: `${formatNum(results.roi, 1)}٪`, tint: "green" },
    { icon: <Clock />, label: "بازگشت سرمایه", value: `${formatNum(results.payback, 1)} سال`, tint: "navy" },
    { icon: <Leaf />, label: "کاهش CO₂ عمر نیروگاه", value: `${formatIRR(results.co2)} kg`, tint: "green" },
    { icon: <TreePine />, label: "معادل درخت‌کاری", value: formatIRR(results.treesEq), sub: "درخت", tint: "green" },
  ];
  return (
    <div className="grid gap-3 animate-fade-in sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((c, i) => <ResultCard key={i} {...c} />)}
    </div>
  );
}

function ResultCard({ icon, label, value, sub, tint }: { icon: React.ReactNode; label: string; value: string; sub?: string; tint: "green" | "gold" | "navy" }) {
  const gradient =
    tint === "green" ? "from-primary/15 to-primary/5 ring-primary/30 text-primary"
    : tint === "gold" ? "from-gold/20 to-gold/5 ring-gold/30 text-gold"
    : "from-navy/15 to-navy/5 ring-navy/30 text-navy";
  return (
    <div className={`glass rounded-2xl bg-gradient-to-br p-4 ring-1 transition hover:scale-[1.02] ${gradient}`}>
      <div className="mb-1.5 flex items-center gap-2 text-xs text-muted-foreground">
        <span className="[&>svg]:h-4 [&>svg]:w-4">{icon}</span>{label}
      </div>
      <div className="text-lg font-black leading-tight">{value}</div>
      {sub && <div className="mt-0.5 text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

function ChartsPanel({ results }: { results: Results }) {
  const cashFlow = results.years.map((y) => ({
    year: `${y.year}`,
    درآمد: Math.round(y.revenue / 1_000_000),
    نگهداری: Math.round(y.maintenance / 1_000_000),
    خالص: Math.round(y.net / 1_000_000),
  }));
  const cumChart = results.years.map((y) => ({
    year: `${y.year}`,
    سود_تجمعی: Math.round(y.cumulative / 1_000_000),
  }));
  const roiChart = results.years.map((y) => ({ year: `${y.year}`, ROI: +y.roi.toFixed(1) }));

  return (
    <div className="grid gap-4 animate-fade-in lg:grid-cols-2">
      <ChartCard title="تولید ماهانه (kWh)">
        <BarChart data={results.monthly}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
          <XAxis dataKey="month" tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <YAxis tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <Tooltip contentStyle={ttip} />
          <Bar dataKey="تولید" fill="oklch(0.62 0.17 150)" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ChartCard>

      <ChartCard title="درآمد ماهانه (میلیون تومان)">
        <AreaChart data={results.monthly}>
          <defs>
            <linearGradient id="incomeG" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="oklch(0.78 0.15 82)" stopOpacity={0.8} />
              <stop offset="100%" stopColor="oklch(0.78 0.15 82)" stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
          <XAxis dataKey="month" tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <YAxis tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <Tooltip contentStyle={ttip} />
          <Area type="monotone" dataKey="درآمد" stroke="oklch(0.78 0.15 82)" strokeWidth={2} fill="url(#incomeG)" />
        </AreaChart>
      </ChartCard>

      <ChartCard title="جریان نقدی سالانه (میلیون تومان)">
        <BarChart data={cashFlow}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
          <XAxis dataKey="year" tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <YAxis tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <Tooltip contentStyle={ttip} /><Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar dataKey="درآمد" fill="oklch(0.78 0.15 82)" radius={[6, 6, 0, 0]} />
          <Bar dataKey="نگهداری" fill="oklch(0.65 0.20 25)" radius={[6, 6, 0, 0]} />
          <Bar dataKey="خالص" fill="oklch(0.62 0.17 150)" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ChartCard>

      <ChartCard title="روند بازده سرمایه (ROI ٪)">
        <LineChart data={roiChart}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
          <XAxis dataKey="year" tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <YAxis tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
          <Tooltip contentStyle={ttip} />
          <Line type="monotone" dataKey="ROI" stroke="oklch(0.62 0.17 150)" strokeWidth={3} dot={false} />
        </LineChart>
      </ChartCard>

      <div className="lg:col-span-2">
        <ChartCard title="پیش‌بینی سود تجمعی (میلیون تومان)">
          <AreaChart data={cumChart}>
            <defs>
              <linearGradient id="cumG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.62 0.17 150)" stopOpacity={0.9} />
                <stop offset="100%" stopColor="oklch(0.62 0.17 150)" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
            <XAxis dataKey="year" tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
            <YAxis tick={{ fill: "rgba(0,0,0,0.6)", fontSize: 10 }} />
            <Tooltip contentStyle={ttip} />
            <Area type="monotone" dataKey="سود_تجمعی" stroke="oklch(0.62 0.17 150)" strokeWidth={3} fill="url(#cumG)" />
          </AreaChart>
        </ChartCard>
      </div>
    </div>
  );
}

const ttip = { background: "#fff", border: "1px solid rgba(0,0,0,0.08)", borderRadius: 12, direction: "rtl" as const, fontSize: 12 };

function ChartCard({ title, children }: { title: string; children: React.ReactElement }) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className="mb-3 text-sm font-black">{title}</div>
      <div className="h-64 w-full"><ResponsiveContainer>{children}</ResponsiveContainer></div>
    </div>
  );
}

function ComparePanel({ a, b, setB }: {
  a: { inputs: CalcInputs; results: Results };
  b: { inputs: CalcInputs; results: Results };
  setB: (v: CalcInputs) => void;
}) {
  const rows: { label: string; a: string; b: string }[] = [
    { label: "ظرفیت (kW)", a: formatNum(a.inputs.capacity), b: formatNum(b.inputs.capacity) },
    { label: "استان/شهر",
      a: `${PROVINCES[a.inputs.provinceIdx].name} — ${PROVINCES[a.inputs.provinceIdx].cities[a.inputs.cityIdx].name}`,
      b: `${PROVINCES[b.inputs.provinceIdx].name} — ${PROVINCES[b.inputs.provinceIdx].cities[b.inputs.cityIdx].name}` },
    { label: "سرمایه اولیه (تومان)", a: formatIRR(a.results.initialInvestment), b: formatIRR(b.results.initialInvestment) },
    { label: "تولید سالانه (kWh)", a: formatIRR(a.results.annualKWh), b: formatIRR(b.results.annualKWh) },
    { label: "درآمد سالانه (تومان)", a: formatIRR(a.results.annualIncome), b: formatIRR(b.results.annualIncome) },
    { label: "سود ۱۰ ساله (تومان)", a: formatIRR(a.results.profit10), b: formatIRR(b.results.profit10) },
    { label: "سود ۲۵ ساله (تومان)", a: formatIRR(a.results.profit25), b: formatIRR(b.results.profit25) },
    { label: "بازگشت سرمایه (سال)", a: formatNum(a.results.payback, 1), b: formatNum(b.results.payback, 1) },
    { label: "ROI کل (٪)", a: formatNum(a.results.roi, 1), b: formatNum(b.results.roi, 1) },
  ];
  return (
    <div className="animate-fade-in space-y-4">
      <div className="glass rounded-2xl p-4">
        <div className="mb-3 text-sm font-bold">تنظیمات نیروگاه B</div>
        <div className="grid gap-3 md:grid-cols-4">
          <NumberField label="ظرفیت (kW)" value={b.inputs.capacity} min={1} max={10000}
            onChange={(v) => setB({ ...b.inputs, capacity: v })} />
          <NumberField label="هزینه هر kW" value={b.inputs.costPerKw} min={0} step={1_000_000}
            onChange={(v) => setB({ ...b.inputs, costPerKw: v })} />
          <NumberField label="راندمان (٪)" value={b.inputs.efficiency} min={50} max={95}
            onChange={(v) => setB({ ...b.inputs, efficiency: v })} />
          <NumberField label="ساعات آفتاب" value={b.inputs.sunHoursDaily} min={1} max={12} step={0.1}
            onChange={(v) => setB({ ...b.inputs, sunHoursDaily: v, sunHoursAnnual: Math.round(v * 365) })} />
        </div>
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-primary/10 text-primary">
            <tr>
              <th className="px-4 py-3 text-right">مقایسه</th>
              <th className="px-4 py-3 text-right">نیروگاه A</th>
              <th className="px-4 py-3 text-right">نیروگاه B</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t border-white/20 hover:bg-white/40">
                <td className="px-4 py-3 font-bold">{r.label}</td>
                <td className="px-4 py-3">{r.a}</td>
                <td className="px-4 py-3 text-primary">{r.b}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
