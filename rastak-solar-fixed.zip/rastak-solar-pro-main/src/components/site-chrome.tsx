import { Link } from "@tanstack/react-router";
import { Phone, MessageCircle } from "lucide-react";
import logoAsset from "@/assets/rastak-logo.png.asset.json";
const logo = logoAsset.url;

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-navy/10 bg-white/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-2.5">
          <img src={logo} alt="لوگو رستاک سولار" width={40} height={40} className="h-10 w-10 shrink-0" />
          <div className="min-w-0 leading-tight">
            <div className="truncate text-sm font-bold sm:text-base">رستاک سولار</div>
            <div className="hidden text-[11px] text-muted-foreground sm:block">عمران و انرژی رستاک</div>
          </div>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <a href="#services" className="hover:text-foreground">خدمات</a>
          <a href="#projects" className="hover:text-foreground">پروژه‌ها</a>
          <a href="#calculator" className="hover:text-foreground">ماشین حساب</a>
          <a href="#engineering" className="hover:text-foreground">طراحی و مهندسی</a>
          <a href="#contact" className="hover:text-foreground">تماس</a>
        </nav>
        <a
          href="tel:09123532459"
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary px-3 py-2 text-xs font-bold text-primary-foreground sm:px-4 sm:text-sm"
        >
          <Phone className="h-4 w-4" />
          تماس
        </a>
      </div>
    </header>
  );
}

export function SiteFooter({ phone1, phone2 }: { phone1: string; phone2: string }) {
  return (
    <footer className="mt-20 border-t border-navy/10 bg-white/60 py-10">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 sm:grid-cols-3 sm:px-6">
        <div>
          <div className="flex items-center gap-2.5">
            <img src={logo} alt="" width={36} height={36} className="h-9 w-9" />
            <span className="font-bold">رستاک سولار</span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            شرکت عمران و انرژی رستاک - طراحی، اجرا و احداث نیروگاه‌های خورشیدی
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-bold text-gradient-gold">تماس مستقیم</h4>
          <div className="flex flex-col gap-2 text-sm">
            <a href={`tel:${phone1}`} className="inline-flex items-center gap-2 hover:text-primary">
              <Phone className="h-4 w-4" />{phone1}
            </a>
            <a href={`tel:${phone2}`} className="inline-flex items-center gap-2 hover:text-primary">
              <Phone className="h-4 w-4" />{phone2}
            </a>
            <a
              href={`https://wa.me/98${phone1.replace(/^0/, "")}`}
              target="_blank"
              rel="noopener"
              className="inline-flex items-center gap-2 text-primary hover:underline"
            >
              <MessageCircle className="h-4 w-4" />واتساپ
            </a>
          </div>
        </div>
        <div className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} شرکت عمران و انرژی رستاک — تمام حقوق محفوظ است.
        </div>
      </div>
    </footer>
  );
}
