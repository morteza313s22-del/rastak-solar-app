import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Send } from "lucide-react";

const schema = z.object({
  full_name: z.string().trim().min(2, "نام را وارد کنید").max(100),
  phone: z.string().trim().min(6, "شماره تماس معتبر نیست").max(20),
  city: z.string().trim().max(80).optional().or(z.literal("")),
  project_type: z.string().trim().max(40).optional().or(z.literal("")),
  proposed_capacity_kw: z.string().optional(),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
});

export function ConsultationForm() {
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const raw = Object.fromEntries(fd) as Record<string, string>;
    const parsed = schema.safeParse(raw);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "اطلاعات نامعتبر است");
      return;
    }
    setLoading(true);
    const cap = raw.proposed_capacity_kw ? Number(raw.proposed_capacity_kw) : null;
    const { error } = await supabase.from("consultations").insert({
      full_name: parsed.data.full_name,
      phone: parsed.data.phone,
      city: parsed.data.city || null,
      project_type: parsed.data.project_type || null,
      proposed_capacity_kw: cap && !isNaN(cap) ? cap : null,
      description: parsed.data.description || null,
    });
    setLoading(false);
    if (error) { toast.error("ارسال ناموفق بود، دوباره تلاش کنید"); return; }
    toast.success("درخواست شما ثبت شد، به‌زودی با شما تماس می‌گیریم");
    (e.target as HTMLFormElement).reset();
  }

  const inputCls = "w-full rounded-xl border border-white/10 bg-background/50 px-4 py-3 outline-none focus:border-primary";

  return (
    <form onSubmit={onSubmit} className="glass-strong grid gap-4 rounded-3xl p-5 sm:p-8">
      <div className="grid gap-4 sm:grid-cols-2">
        <input name="full_name" required placeholder="نام و نام خانوادگی" className={inputCls} />
        <input name="phone" required placeholder="شماره تماس" className={inputCls} inputMode="tel" />
        <input name="city" placeholder="شهر" className={inputCls} />
        <select name="project_type" className={inputCls} defaultValue="">
          <option value="">نوع نیروگاه</option>
          <option value="residential">خانگی</option>
          <option value="agricultural">کشاورزی</option>
          <option value="industrial">صنعتی</option>
        </select>
        <input name="proposed_capacity_kw" type="number" min={1} max={1000} placeholder="توان پیشنهادی (kW)" className={`${inputCls} sm:col-span-2`} />
        <textarea name="description" placeholder="توضیحات" rows={4} className={`${inputCls} sm:col-span-2`} />
      </div>
      <button
        type="submit"
        disabled={loading}
        className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-bold text-primary-foreground shadow-lg shadow-primary/20 transition hover:opacity-95 disabled:opacity-60"
      >
        <Send className="h-5 w-5" />
        {loading ? "در حال ارسال..." : "ثبت درخواست مشاوره رایگان"}
      </button>
    </form>
  );
}
