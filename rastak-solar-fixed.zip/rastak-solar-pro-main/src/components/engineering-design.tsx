import { useMemo, useState } from "react";
import {
  Cpu, Cable, Layers, Ruler, AlertTriangle, CheckCircle2, Download, Printer,
  Zap, Settings2, Boxes, FileText,
} from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { toast } from "sonner";
import logoAsset from "@/assets/rastak-logo.png.asset.json";

const fmt = (n: number, d = 0) =>
  new Intl.NumberFormat("fa-IR", { maximumFractionDigits: d }).format(Number.isFinite(n) ? n : 0);

/* ---------------- inverter database ---------------- */
export interface Inverter {
  brand: string;
  model: string;
  acKw: number;
  mppt: number;
  maxInputCurrent: number;
  mpptMin: number;
  mpptMax: number;
  maxVdc: number;
  phase: "تکفاز" | "سه‌فاز";
}

export const INVERTERS: Inverter[] = [
  { brand: "Growatt", model: "MIN 5000TL-X", acKw: 5, mppt: 2, maxInputCurrent: 13.5, mpptMin: 80, mpptMax: 500, maxVdc: 550, phase: "تکفاز" },
  { brand: "Growatt", model: "MOD 10KTL3-X", acKw: 10, mppt: 2, maxInputCurrent: 16, mpptMin: 140, mpptMax: 850, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Huawei", model: "SUN2000-20KTL-M2", acKw: 20, mppt: 2, maxInputCurrent: 22, mpptMin: 160, mpptMax: 950, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "SMA", model: "Sunny Tripower 25000TL", acKw: 25, mppt: 2, maxInputCurrent: 33, mpptMin: 150, mpptMax: 800, maxVdc: 1000, phase: "سه‌فاز" },
  { brand: "Huawei", model: "SUN2000-33KTL-A", acKw: 33, mppt: 4, maxInputCurrent: 22, mpptMin: 200, mpptMax: 1000, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Sungrow", model: "SG50CX", acKw: 50, mppt: 5, maxInputCurrent: 30, mpptMin: 200, mpptMax: 1000, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Huawei", model: "SUN2000-60KTL-M0", acKw: 60, mppt: 6, maxInputCurrent: 22, mpptMin: 200, mpptMax: 1000, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Sungrow", model: "SG110CX", acKw: 110, mppt: 9, maxInputCurrent: 30, mpptMin: 200, mpptMax: 1000, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Huawei", model: "SUN2000-125KTL-M0", acKw: 125, mppt: 10, maxInputCurrent: 26, mpptMin: 200, mpptMax: 1000, maxVdc: 1100, phase: "سه‌فاز" },
  { brand: "Sungrow", model: "SG225HX", acKw: 225, mppt: 12, maxInputCurrent: 30, mpptMin: 500, mpptMax: 1500, maxVdc: 1500, phase: "سه‌فاز" },
];

/* ---------------- engine ---------------- */
export interface EngInputs {
  capacityKw: number;
  panelWatt: number;
  voc: number;
  vmp: number;
  isc: number;
  imp: number;
  panelCountMode: "auto" | "manual";
  panelCountManual: number;
  panelLength: number;
  panelWidth: number;
  panelWeight: number;
  inverterIdx: number;
  mpptMin: number;
  mpptMax: number;
  maxVdc: number;
  dcLength: number;
  dcDrop: number;
  acLength: number;
  acVoltage: number;
  acDrop: number;
  rowsPanelsPerRow: number;
  tempMinC: number;
}

export const DEFAULT_ENG: EngInputs = {
  capacityKw: 100,
  panelWatt: 580,
  voc: 51.2,
  vmp: 42.8,
  isc: 14.3,
  imp: 13.6,
  panelCountMode: "auto",
  panelCountManual: 173,
  panelLength: 2.28,
  panelWidth: 1.13,
  panelWeight: 32,
  inverterIdx: 5,
  mpptMin: 200,
  mpptMax: 1000,
  maxVdc: 1100,
  dcLength: 60,
  dcDrop: 1.5,
  acLength: 40,
  acVoltage: 400,
  acDrop: 2,
  rowsPanelsPerRow: 20,
  tempMinC: -10,
};

const RHO_CU = 0.0175; // Ω·mm²/m
const STD_SECTIONS = [1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300];
const pickSection = (a: number) => STD_SECTIONS.find((s) => s >= a) ?? 400;

export function computeEngineering(i: EngInputs) {
  const panelWatt = Math.max(1, i.panelWatt);
  const autoCount = Math.ceil((i.capacityKw * 1000) / panelWatt);
  const panelCount = i.panelCountMode === "auto" ? autoCount : Math.max(1, Math.round(i.panelCountManual));
  const arrayKw = (panelCount * panelWatt) / 1000;

  // temperature correction: Voc rises in cold (-0.28%/°C from 25°C), Vmp falls in heat
  const vocCold = i.voc * (1 + (25 - i.tempMinC) * 0.0028);
  const vmpHot = i.vmp * (1 - 45 * 0.0035);

  const maxByMppt = Math.floor(i.mpptMax / Math.max(1, vocCold));
  const maxByVdc = Math.floor(i.maxVdc / Math.max(1, vocCold));
  const maxPerString = Math.max(0, Math.min(maxByMppt, maxByVdc));
  const minPerString = Math.ceil(i.mpptMin / Math.max(1, vmpHot));

  const feasible = maxPerString >= minPerString && maxPerString > 0;
  let panelsPerString = feasible ? maxPerString : Math.max(1, minPerString);
  // prefer a division that balances strings
  if (feasible) {
    const need = Math.ceil(panelCount / panelsPerString);
    const balanced = Math.ceil(panelCount / Math.max(1, need));
    if (balanced >= minPerString && balanced <= maxPerString) panelsPerString = balanced;
  }

  const strings = Math.ceil(panelCount / Math.max(1, panelsPerString));
  const inverter = INVERTERS[i.inverterIdx] ?? INVERTERS[0];
  const mpptCount = Math.max(1, inverter.mppt);
  const stringsPerMppt = Math.ceil(strings / mpptCount);
  const panelsPerMppt = Math.ceil(panelCount / mpptCount);

  const stringVoc = panelsPerString * vocCold;
  const stringVmp = panelsPerString * i.vmp;
  const stringIsc = i.isc;
  const mpptCurrent = stringsPerMppt * i.imp;

  const warnings: { level: "error" | "warn" | "ok"; text: string }[] = [];
  if (stringVoc > i.maxVdc)
    warnings.push({ level: "error", text: `ولتاژ مدار باز رشته (${fmt(stringVoc, 0)} ولت) از حداکثر ولتاژ DC اینورتر (${fmt(i.maxVdc)} ولت) بیشتر است.` });
  else if (stringVoc > i.mpptMax)
    warnings.push({ level: "error", text: `ولتاژ رشته (${fmt(stringVoc, 0)} ولت) از سقف بازه MPPT (${fmt(i.mpptMax)} ولت) خارج شده است.` });
  if (stringVmp < i.mpptMin)
    warnings.push({ level: "error", text: `ولتاژ کاری رشته (${fmt(stringVmp, 0)} ولت) کمتر از حداقل MPPT (${fmt(i.mpptMin)} ولت) است؛ تعداد پنل رشته را افزایش دهید.` });
  if (panelsPerString < minPerString)
    warnings.push({ level: "warn", text: `تعداد پنل هر رشته کم است؛ حداقل ${fmt(minPerString)} پنل لازم است.` });
  if (panelsPerString > maxPerString && maxPerString > 0)
    warnings.push({ level: "warn", text: `تعداد پنل هر رشته زیاد است؛ حداکثر ${fmt(maxPerString)} پنل مجاز است.` });
  if (mpptCurrent > inverter.maxInputCurrent)
    warnings.push({ level: "warn", text: `جریان هر MPPT (${fmt(mpptCurrent, 1)} آمپر) از حد مجاز اینورتر (${fmt(inverter.maxInputCurrent, 1)} آمپر) بیشتر است.` });
  const dcAcRatio = arrayKw / Math.max(1, inverter.acKw);
  if (dcAcRatio > 1.35) warnings.push({ level: "warn", text: `نسبت DC/AC برابر ${fmt(dcAcRatio, 2)} است؛ اینورتر بزرگ‌تر یا تعداد بیشتری پیشنهاد می‌شود.` });
  if (warnings.length === 0)
    warnings.push({ level: "ok", text: "طراحی رشته‌ها در محدوده مجاز اینورتر است و هشداری وجود ندارد." });

  /* ---- inverter suggestion ---- */
  const suggestions = INVERTERS.map((inv) => {
    const qty = Math.max(1, Math.round(arrayKw / (inv.acKw * 1.15)) || 1);
    const totalAc = qty * inv.acKw;
    const ratio = arrayKw / totalAc;
    return { inv, qty, totalAc, ratio };
  })
    .filter((s) => s.ratio >= 0.9 && s.ratio <= 1.35 && s.qty <= 12)
    .sort((a, b) => Math.abs(a.ratio - 1.15) - Math.abs(b.ratio - 1.15))
    .slice(0, 3);

  /* ---- DC cable ---- */
  const dcCurrent = i.isc * 1.25;
  const dcVoltDrop = (i.dcDrop / 100) * Math.max(1, stringVmp);
  const dcArea = (2 * i.dcLength * dcCurrent * RHO_CU) / Math.max(0.1, dcVoltDrop);
  const dcSection = pickSection(dcArea);
  const dcActualDrop = (2 * i.dcLength * dcCurrent * RHO_CU) / dcSection;
  const dcDropPct = (dcActualDrop / Math.max(1, stringVmp)) * 100;

  /* ---- AC cable ---- */
  const threePhase = i.acVoltage >= 380;
  const acCurrent = threePhase
    ? (inverter.acKw * 1000) / (Math.sqrt(3) * i.acVoltage * 0.95)
    : (inverter.acKw * 1000) / (i.acVoltage * 0.95);
  const acVoltDrop = (i.acDrop / 100) * i.acVoltage;
  const acArea = threePhase
    ? (Math.sqrt(3) * i.acLength * acCurrent * RHO_CU) / Math.max(0.1, acVoltDrop)
    : (2 * i.acLength * acCurrent * RHO_CU) / Math.max(0.1, acVoltDrop);
  const acSection = pickSection(acArea);
  const acActualDrop =
    ((threePhase ? Math.sqrt(3) : 2) * i.acLength * acCurrent * RHO_CU) / acSection;
  const acDropPct = (acActualDrop / i.acVoltage) * 100;
  const acCableLabel = threePhase
    ? `کابل مسی ۴×${fmt(acSection, 1)} + ارت (سه‌فاز)`
    : `کابل مسی ۲×${fmt(acSection, 1)} + ارت (تکفاز)`;

  /* ---- structure ---- */
  const perRow = Math.max(1, Math.round(i.rowsPanelsPerRow));
  const rows = Math.ceil(panelCount / perRow);
  const rowLength = perRow * i.panelWidth; // portrait mounting
  const postsPerRow = Math.ceil(rowLength / 2.5) + 1;
  const posts = postsPerRow * rows;
  const railLength = rows * rowLength * 2; // two rails per row
  const postLength = posts * 2.2;
  const profileLength = railLength + postLength;
  const structureWeight = profileLength * 4.2 + posts * 6; // kg
  const panelsWeight = panelCount * i.panelWeight;
  const modulesArea = panelCount * i.panelLength * i.panelWidth;
  const landArea = modulesArea * 2;

  return {
    panelCount, arrayKw, autoCount, vocCold, vmpHot,
    minPerString, maxPerString, panelsPerString, strings, stringsPerMppt, panelsPerMppt,
    stringVoc, stringVmp, stringIsc, mpptCurrent, mpptCount, inverter, dcAcRatio,
    warnings, suggestions,
    dcCurrent, dcSection, dcDropPct,
    acCurrent, acSection, acDropPct, acCableLabel, threePhase,
    rows, perRow, posts, profileLength, structureWeight, panelsWeight, modulesArea, landArea,
  };
}

export type EngResults = ReturnType<typeof computeEngineering>;

/* ---------------- UI ---------------- */
export function EngineeringDesign({
  sunHoursAnnual = 1900,
  tariff = 16000,
}: { sunHoursAnnual?: number; tariff?: number }) {
  const [i, setI] = useState<EngInputs>(DEFAULT_ENG);
  const set = <K extends keyof EngInputs>(k: K, v: EngInputs[K]) => setI((p) => ({ ...p, [k]: v }));
  const r = useMemo(() => computeEngineering(i), [i]);

  const annualKWh = Math.round(r.arrayKw * sunHoursAnnual * 0.78);
  const annualIncome = annualKWh * tariff;

  const applyInverter = (idx: number) => {
    const inv = INVERTERS[idx];
    setI((p) => ({ ...p, inverterIdx: idx, mpptMin: inv.mpptMin, mpptMax: inv.mpptMax, maxVdc: inv.maxVdc }));
  };

  /* ---- report ---- */
  const buildHTML = () => {
    const date = new Intl.DateTimeFormat("fa-IR", { dateStyle: "full" }).format(new Date());
    const rowsHtml = (list: [string, string][]) =>
      list.map(([k, v]) => `<tr><td class="k">${k}</td><td class="v">${v}</td></tr>`).join("");

    const project: [string, string][] = [
      ["ظرفیت نیروگاه", `${fmt(i.capacityKw)} کیلووات`],
      ["توان هر پنل", `${fmt(i.panelWatt)} وات`],
      ["تعداد کل پنل", `${fmt(r.panelCount)} عدد`],
      ["ظرفیت واقعی آرایه", `${fmt(r.arrayKw, 2)} کیلووات`],
      ["ابعاد پنل", `${fmt(i.panelLength, 2)} × ${fmt(i.panelWidth, 2)} متر`],
      ["مساحت پنل‌ها", `${fmt(r.modulesArea)} متر مربع`],
      ["سطح زمین مورد نیاز", `${fmt(r.landArea)} متر مربع`],
    ];
    const strings: [string, string][] = [
      ["تعداد پنل در هر رشته (String)", `${fmt(r.panelsPerString)} عدد`],
      ["تعداد رشته", `${fmt(r.strings)} رشته`],
      ["تعداد رشته روی هر MPPT", `${fmt(r.stringsPerMppt)} رشته`],
      ["تعداد پنل روی هر MPPT", `${fmt(r.panelsPerMppt)} عدد`],
      ["ولتاژ مدار باز رشته (سرد)", `${fmt(r.stringVoc, 0)} ولت`],
      ["ولتاژ کاری رشته", `${fmt(r.stringVmp, 0)} ولت`],
      ["جریان هر MPPT", `${fmt(r.mpptCurrent, 1)} آمپر`],
      ["بازه مجاز پنل در رشته", `${fmt(r.minPerString)} تا ${fmt(r.maxPerString)} عدد`],
    ];
    const inv: [string, string][] = [
      ["اینورتر انتخابی", `${r.inverter.brand} ${r.inverter.model}`],
      ["توان AC", `${fmt(r.inverter.acKw)} کیلووات — ${r.inverter.phase}`],
      ["تعداد MPPT", `${fmt(r.inverter.mppt)}`],
      ["بازه ولتاژ MPPT", `${fmt(r.inverter.mpptMin)} تا ${fmt(r.inverter.mpptMax)} ولت`],
      ["نسبت DC/AC", fmt(r.dcAcRatio, 2)],
      ...(r.suggestions.length
        ? ([["پیشنهاد سیستم", r.suggestions.map((s) => `${fmt(s.qty)} × ${s.inv.brand} ${s.inv.model} (${fmt(s.inv.acKw)}kW)`).join(" | ")]] as [string, string][])
        : []),
    ];
    const cable: [string, string][] = [
      ["جریان طراحی DC", `${fmt(r.dcCurrent, 1)} آمپر`],
      ["کابل DC پیشنهادی", `مسی ${fmt(r.dcSection, 1)} میلی‌متر مربع (طول ${fmt(i.dcLength)} متر)`],
      ["افت ولتاژ DC", `${fmt(r.dcDropPct, 2)} ٪`],
      ["جریان AC", `${fmt(r.acCurrent, 1)} آمپر`],
      ["کابل AC پیشنهادی", `${r.acCableLabel} (طول ${fmt(i.acLength)} متر)`],
      ["افت ولتاژ AC", `${fmt(r.acDropPct, 2)} ٪`],
    ];
    const struct: [string, string][] = [
      ["تعداد ردیف پنل", `${fmt(r.rows)} ردیف`],
      ["تعداد پنل در هر ردیف", `${fmt(r.perRow)} عدد`],
      ["تعداد پایه", `${fmt(r.posts)} پایه`],
      ["طول تقریبی پروفیل", `${fmt(r.profileLength)} متر`],
      ["وزن تقریبی سازه", `${fmt(r.structureWeight)} کیلوگرم`],
      ["وزن پنل‌ها", `${fmt(r.panelsWeight)} کیلوگرم`],
    ];
    const energy: [string, string][] = [
      ["تولید سالانه برآوردی", `${fmt(annualKWh)} کیلووات‌ساعت`],
      ["درآمد سالانه تقریبی", `${fmt(annualIncome)} تومان`],
    ];

    const section = (n: string, t: string, list: [string, string][]) => `
  <div class="section">
    <div class="section-head"><span class="badge">${n}</span><h3>${t}</h3></div>
    <table><tbody>${rowsHtml(list)}</tbody></table>
  </div>`;

    return `<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8" />
<title>پیشنهاد طراحی نیروگاه خورشیدی رستاک سولار</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
  *,*::before,*::after{box-sizing:border-box}
  html,body{margin:0;padding:0;font-family:'Vazirmatn',Tahoma,sans-serif;color:#0f1e3d;background:#fff}
  .page{width:794px;margin:0 auto;padding:36px 40px;background:#fff}
  .brand{display:flex;align-items:center;justify-content:space-between;gap:16px;padding-bottom:16px;border-bottom:3px solid #16a34a}
  .brand-l{display:flex;align-items:center;gap:14px}
  .brand img{width:64px;height:64px;object-fit:contain}
  .brand h1{margin:0;font-size:20px;font-weight:900}
  .brand .sub{font-size:12px;color:#4b5563;margin-top:2px}
  .date-chip{background:linear-gradient(135deg,#16a34a,#0f9d58);color:#fff;padding:8px 14px;border-radius:999px;font-size:12px;font-weight:700}
  .title-wrap{margin:22px 0 18px;text-align:center}
  .title-wrap h2{margin:0;font-size:23px;font-weight:900}
  .title-wrap .accent{display:inline-block;width:80px;height:4px;background:linear-gradient(90deg,#eab308,#16a34a);border-radius:4px;margin-top:10px}
  .kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0 4px}
  .kpi{border:1.5px solid #d1fae5;border-radius:12px;padding:10px 12px;background:linear-gradient(135deg,#f0fdf4,#fefce8)}
  .kpi .lbl{font-size:10px;color:#4b5563}
  .kpi .val{font-size:14px;font-weight:900;color:#065f46;margin-top:2px}
  .section{margin-top:20px}
  .section-head{display:flex;align-items:center;gap:10px;margin-bottom:10px}
  .section-head .badge{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#16a34a,#0f9d58);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:13px}
  .section-head h3{margin:0;font-size:15px;font-weight:800}
  table{width:100%;border-collapse:separate;border-spacing:0;border:1.5px solid #d1d5db;border-radius:12px;overflow:hidden;font-size:12.5px}
  td{padding:9px 14px;border-bottom:1px solid #e5e7eb;text-align:right}
  tr:last-child td{border-bottom:none}
  td.k{background:#f9fafb;color:#374151;font-weight:600;width:45%}
  td.v{color:#065f46;font-weight:800;background:#f0fdf4}
  .footer{margin-top:26px;padding-top:14px;border-top:2px solid #eab308;text-align:center;font-size:11px;color:#374151;line-height:1.9}
  @media print{@page{size:A4;margin:0}body{margin:0}}
</style></head>
<body><div class="page" id="report-root">
  <div class="brand">
    <div class="brand-l">
      <img src="${logoAsset.url}" alt="لوگو" crossorigin="anonymous" />
      <div><h1>شرکت عمران و انرژی رستاک</h1><div class="sub">طراحی، مهندسی و اجرای نیروگاه‌های خورشیدی</div></div>
    </div>
    <div class="date-chip">${date}</div>
  </div>
  <div class="title-wrap"><h2>پیشنهاد طراحی نیروگاه خورشیدی رستاک سولار</h2><div class="accent"></div></div>
  <div class="kpi-row">
    <div class="kpi"><div class="lbl">ظرفیت</div><div class="val">${fmt(r.arrayKw, 1)} kW</div></div>
    <div class="kpi"><div class="lbl">تعداد پنل</div><div class="val">${fmt(r.panelCount)}</div></div>
    <div class="kpi"><div class="lbl">تعداد رشته</div><div class="val">${fmt(r.strings)}</div></div>
    <div class="kpi"><div class="lbl">سطح زمین</div><div class="val">${fmt(r.landArea)} m²</div></div>
  </div>
  ${section("۱", "مشخصات پروژه", project)}
  ${section("۲", "طراحی String", strings)}
  ${section("۳", "اینورتر پیشنهادی", inv)}
  ${section("۴", "کابل پیشنهادی", cable)}
  ${section("۵", "استراکچر و سازه", struct)}
  ${section("۶", "تولید و درآمد", energy)}
  <div class="footer">
    <strong>شرکت عمران و انرژی رستاک</strong><br/>۰۹۱۲۳۵۳۲۴۵۹ — ۰۹۳۶۸۵۱۰۰۹۰
  </div>
</div></body></html>`;
  };

  const renderIframe = async () => {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("aria-hidden", "true");
    iframe.style.cssText = "position:fixed;top:0;left:-10000px;width:820px;height:1200px;border:0;background:#fff;";
    document.body.appendChild(iframe);
    const doc = iframe.contentDocument!;
    doc.open();
    doc.write(buildHTML());
    doc.close();
    try { await (doc as Document & { fonts?: { ready: Promise<unknown> } }).fonts?.ready; } catch { /* noop */ }
    const img = doc.querySelector("img");
    if (img && !img.complete) await new Promise<void>((res) => { img.onload = () => res(); img.onerror = () => res(); });
    await new Promise((res) => setTimeout(res, 80));
    const body = doc.querySelector<HTMLElement>("#report-root") ?? doc.body;
    iframe.style.height = `${body.scrollHeight + 20}px`;
    return { iframe, body };
  };

  const exportPDF = async () => {
    toast.loading("در حال ساخت گزارش طراحی...", { id: "eng-pdf" });
    let frame: HTMLIFrameElement | null = null;
    try {
      const rendered = await renderIframe();
      frame = rendered.iframe;
      const canvas = await html2canvas(rendered.body, {
        scale: 2, useCORS: true, backgroundColor: "#ffffff", logging: false,
        windowWidth: rendered.body.scrollWidth, windowHeight: rendered.body.scrollHeight,
      });
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgH = (canvas.height * pageW) / canvas.width;
      const data = canvas.toDataURL("image/jpeg", 0.95);
      let left = imgH, pos = 0;
      pdf.addImage(data, "JPEG", 0, pos, pageW, imgH);
      left -= pageH;
      while (left > 0) {
        pos = left - imgH;
        pdf.addPage();
        pdf.addImage(data, "JPEG", 0, pos, pageW, imgH);
        left -= pageH;
      }
      pdf.save(`طراحی-نیروگاه-رستاک-${i.capacityKw}kW.pdf`);
      toast.success("گزارش طراحی دانلود شد", { id: "eng-pdf" });
    } catch (e) {
      toast.error(`خطا در ساخت گزارش: ${e instanceof Error ? e.message : String(e)}`, { id: "eng-pdf" });
    } finally {
      if (frame?.parentNode) frame.parentNode.removeChild(frame);
    }
  };

  const printReport = () => {
    const w = window.open("", "_blank", "width=900,height=1000");
    if (!w) { toast.error("پنجره چاپ باز نشد"); return; }
    w.document.open();
    w.document.write(buildHTML() + `<script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),500)});<\/script>`);
    w.document.close();
  };

  return (
    <div className="space-y-5">
      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi icon={<Boxes className="h-4 w-4" />} label="تعداد کل پنل" value={`${fmt(r.panelCount)} عدد`} />
        <Kpi icon={<Layers className="h-4 w-4" />} label="تعداد رشته (String)" value={`${fmt(r.strings)} رشته`} />
        <Kpi icon={<Cpu className="h-4 w-4" />} label="اینورتر" value={`${fmt(r.inverter.acKw)} kW`} sub={r.inverter.model} />
        <Kpi icon={<Ruler className="h-4 w-4" />} label="سطح زمین" value={`${fmt(r.landArea)} m²`} />
      </div>

      {/* Warnings */}
      <div className="space-y-2">
        {r.warnings.map((w, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-2 rounded-xl border p-3 text-sm ${
              w.level === "ok"
                ? "border-primary/30 bg-primary/10 text-primary"
                : w.level === "warn"
                  ? "border-gold/40 bg-gold/10 text-foreground"
                  : "border-destructive/40 bg-destructive/10 text-destructive"
            }`}
          >
            {w.level === "ok" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />}
            <span className="font-semibold leading-6">{w.text}</span>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Panel + string inputs */}
        <Card title="مشخصات پنل و آرایه" icon={<Settings2 className="h-4 w-4" />}>
          <div className="grid grid-cols-2 gap-3">
            <NumField label="ظرفیت نیروگاه (kW)" value={i.capacityKw} onChange={(v) => set("capacityKw", v)} step={1} />
            <NumField label="توان پنل (W)" value={i.panelWatt} onChange={(v) => set("panelWatt", v)} step={10} />
            <NumField label="Voc پنل (V)" value={i.voc} onChange={(v) => set("voc", v)} step={0.1} />
            <NumField label="Vmp پنل (V)" value={i.vmp} onChange={(v) => set("vmp", v)} step={0.1} />
            <NumField label="Isc پنل (A)" value={i.isc} onChange={(v) => set("isc", v)} step={0.1} />
            <NumField label="Imp پنل (A)" value={i.imp} onChange={(v) => set("imp", v)} step={0.1} />
            <NumField label="طول پنل (m)" value={i.panelLength} onChange={(v) => set("panelLength", v)} step={0.01} />
            <NumField label="عرض پنل (m)" value={i.panelWidth} onChange={(v) => set("panelWidth", v)} step={0.01} />
          </div>
          <div className="mt-3 flex gap-2">
            {(["auto", "manual"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => set("panelCountMode", m)}
                className={`flex-1 rounded-xl px-3 py-2 text-xs font-bold transition ${
                  i.panelCountMode === m ? "bg-primary text-primary-foreground" : "glass"
                }`}
              >
                {m === "auto" ? "تعداد پنل خودکار" : "تعداد پنل دستی"}
              </button>
            ))}
          </div>
          {i.panelCountMode === "manual" && (
            <div className="mt-3">
              <NumField label="تعداد کل پنل" value={i.panelCountManual} onChange={(v) => set("panelCountManual", v)} step={1} />
            </div>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            ظرفیت واقعی آرایه: <b className="text-foreground">{fmt(r.arrayKw, 2)} کیلووات</b> — بازه مجاز پنل در هر رشته:{" "}
            <b className="text-foreground">{fmt(r.minPerString)} تا {fmt(r.maxPerString)}</b>
          </p>
        </Card>

        {/* Inverter */}
        <Card title="اینورتر و بازه MPPT" icon={<Cpu className="h-4 w-4" />}>
          <label className="block text-xs font-bold text-muted-foreground">انتخاب اینورتر از بانک اطلاعات</label>
          <select
            value={i.inverterIdx}
            onChange={(e) => applyInverter(Number(e.target.value))}
            className="mt-1.5 w-full rounded-xl border border-navy/15 bg-white/70 px-3 py-2.5 text-sm font-semibold outline-none focus:ring-2 focus:ring-primary/40"
          >
            {INVERTERS.map((inv, idx) => (
              <option key={inv.model} value={idx}>
                {inv.brand} — {inv.model} ({inv.acKw}kW / {inv.mppt} MPPT)
              </option>
            ))}
          </select>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <NumField label="حداقل ولتاژ MPPT (V)" value={i.mpptMin} onChange={(v) => set("mpptMin", v)} step={10} />
            <NumField label="حداکثر ولتاژ MPPT (V)" value={i.mpptMax} onChange={(v) => set("mpptMax", v)} step={10} />
            <NumField label="حداکثر ولتاژ DC (V)" value={i.maxVdc} onChange={(v) => set("maxVdc", v)} step={50} />
            <NumField label="حداقل دمای منطقه (°C)" value={i.tempMinC} onChange={(v) => set("tempMinC", v)} step={1} />
          </div>
          <div className="mt-4 space-y-2">
            <div className="text-xs font-bold text-muted-foreground">پیشنهاد سیستم برای {fmt(r.arrayKw, 1)} کیلووات</div>
            {r.suggestions.length === 0 && (
              <p className="text-xs text-muted-foreground">ترکیب مناسبی در بانک اطلاعات یافت نشد؛ ظرفیت را تغییر دهید.</p>
            )}
            {r.suggestions.map((s) => (
              <button
                key={s.inv.model}
                type="button"
                onClick={() => applyInverter(INVERTERS.indexOf(s.inv))}
                className="flex w-full items-center justify-between gap-2 rounded-xl glass px-3 py-2.5 text-right text-sm transition hover:ring-1 hover:ring-primary/40"
              >
                <span className="font-bold">
                  {fmt(s.qty)} عدد {s.inv.brand} {s.inv.model}
                </span>
                <span className="text-xs text-muted-foreground">
                  {fmt(s.totalAc)} kW AC — DC/AC {fmt(s.ratio, 2)}
                </span>
              </button>
            ))}
          </div>
        </Card>

        {/* String design results */}
        <Card title="طراحی String" icon={<Layers className="h-4 w-4" />}>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Stat label="پنل در هر String" value={fmt(r.panelsPerString)} />
            <Stat label="تعداد String" value={fmt(r.strings)} />
            <Stat label="String روی هر MPPT" value={fmt(r.stringsPerMppt)} />
            <Stat label="پنل روی هر MPPT" value={fmt(r.panelsPerMppt)} />
            <Stat label="Voc رشته (سرد)" value={`${fmt(r.stringVoc, 0)} V`} />
            <Stat label="Vmp رشته" value={`${fmt(r.stringVmp, 0)} V`} />
            <Stat label="جریان هر MPPT" value={`${fmt(r.mpptCurrent, 1)} A`} />
            <Stat label="تعداد MPPT" value={fmt(r.mpptCount)} />
            <Stat label="نسبت DC/AC" value={fmt(r.dcAcRatio, 2)} />
          </div>
        </Card>

        {/* Cables */}
        <Card title="محاسبه کابل" icon={<Cable className="h-4 w-4" />}>
          <div className="rounded-xl glass p-3">
            <div className="mb-2 text-xs font-black text-primary">کابل DC</div>
            <div className="grid grid-cols-2 gap-3">
              <NumField label="طول کابل DC (m)" value={i.dcLength} onChange={(v) => set("dcLength", v)} step={1} />
              <NumField label="افت ولتاژ مجاز (٪)" value={i.dcDrop} onChange={(v) => set("dcDrop", v)} step={0.1} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Stat label="جریان طراحی" value={`${fmt(r.dcCurrent, 1)} A`} />
              <Stat label="سطح مقطع پیشنهادی" value={`${fmt(r.dcSection, 1)} mm²`} highlight />
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">افت ولتاژ واقعی: {fmt(r.dcDropPct, 2)} ٪</p>
          </div>
          <div className="mt-3 rounded-xl glass p-3">
            <div className="mb-2 text-xs font-black text-gold">کابل AC</div>
            <div className="grid grid-cols-2 gap-3">
              <NumField label="فاصله تا تابلو (m)" value={i.acLength} onChange={(v) => set("acLength", v)} step={1} />
              <NumField label="ولتاژ شبکه (V)" value={i.acVoltage} onChange={(v) => set("acVoltage", v)} step={10} />
              <NumField label="افت ولتاژ مجاز (٪)" value={i.acDrop} onChange={(v) => set("acDrop", v)} step={0.1} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Stat label="جریان AC" value={`${fmt(r.acCurrent, 1)} A`} />
              <Stat label="کابل پیشنهادی" value={`${fmt(r.acSection, 1)} mm²`} highlight />
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">{r.acCableLabel} — افت واقعی {fmt(r.acDropPct, 2)} ٪</p>
          </div>
        </Card>

        {/* Structure */}
        <Card title="استراکچر و سازه" icon={<Ruler className="h-4 w-4" />}>
          <div className="grid grid-cols-2 gap-3">
            <NumField label="تعداد پنل در هر ردیف" value={i.rowsPanelsPerRow} onChange={(v) => set("rowsPanelsPerRow", v)} step={1} />
            <NumField label="وزن هر پنل (kg)" value={i.panelWeight} onChange={(v) => set("panelWeight", v)} step={1} />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Stat label="تعداد ردیف" value={fmt(r.rows)} />
            <Stat label="تعداد پایه" value={fmt(r.posts)} />
            <Stat label="طول پروفیل" value={`${fmt(r.profileLength)} m`} />
            <Stat label="وزن سازه" value={`${fmt(r.structureWeight)} kg`} />
            <Stat label="وزن پنل‌ها" value={`${fmt(r.panelsWeight)} kg`} />
            <Stat label="مساحت پنل‌ها" value={`${fmt(r.modulesArea)} m²`} />
          </div>
        </Card>

        {/* Energy */}
        <Card title="تولید و درآمد تقریبی" icon={<Zap className="h-4 w-4" />}>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="تولید سالانه" value={`${fmt(annualKWh)} kWh`} highlight />
            <Stat label="درآمد سالانه" value={`${fmt(annualIncome)} تومان`} highlight />
          </div>
          <p className="mt-3 text-[11px] text-muted-foreground">
            بر مبنای {fmt(sunHoursAnnual)} ساعت تابش سالانه و راندمان کل ۷۸٪ محاسبه شده است.
          </p>
        </Card>
      </div>

      {/* Report actions */}
      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={exportPDF}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 text-sm font-black text-primary-foreground shadow-lg shadow-primary/25 sm:flex-none"
        >
          <FileText className="h-4 w-4" />
          ساخت گزارش پروژه (PDF)
        </button>
        <button
          type="button"
          onClick={exportPDF}
          className="inline-flex items-center justify-center gap-2 rounded-xl glass-strong px-5 py-3.5 text-sm font-bold"
        >
          <Download className="h-4 w-4 text-gold" />
          دانلود
        </button>
        <button
          type="button"
          onClick={printReport}
          className="inline-flex items-center justify-center gap-2 rounded-xl glass-strong px-5 py-3.5 text-sm font-bold"
        >
          <Printer className="h-4 w-4 text-primary" />
          چاپ
        </button>
      </div>
    </div>
  );
}

/* ---------------- small UI pieces ---------------- */
function Card({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="glass rounded-2xl p-4 sm:p-5">
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary/25 to-gold/15 text-primary">
          {icon}
        </span>
        <h3 className="text-sm font-black sm:text-base">{title}</h3>
      </div>
      {children}
    </section>
  );
}

function NumField({
  label, value, onChange, step = 1,
}: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <label className="block">
      <span className="block text-[11px] font-bold text-muted-foreground">{label}</span>
      <input
        type="number"
        inputMode="decimal"
        step={step}
        value={Number.isFinite(value) ? value : 0}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full rounded-xl border border-navy/15 bg-white/70 px-3 py-2.5 text-sm font-bold outline-none focus:ring-2 focus:ring-primary/40"
      />
    </label>
  );
}

function Stat({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`rounded-xl border p-3 ${highlight ? "border-primary/30 bg-primary/10" : "border-navy/10 bg-white/60"}`}>
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className={`mt-1 text-sm font-black ${highlight ? "text-primary" : ""}`}>{value}</div>
    </div>
  );
}

function Kpi({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex items-center gap-2 text-primary">
        {icon}
        <span className="text-[11px] font-bold text-muted-foreground">{label}</span>
      </div>
      <div className="mt-2 text-lg font-black">{value}</div>
      {sub && <div className="truncate text-[11px] text-muted-foreground">{sub}</div>}
    </div>
  );
}
