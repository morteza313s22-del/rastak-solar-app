import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ir.rastaksolar.app',
  appName: 'Rastak solar pro',
  webDir: '.output/public',
};

export default config;
